import datetime
import os
import json
import math

from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerInteractEvent, BlockBreakEvent
from endstone.plugin import Plugin
from endstone.form import ActionForm, ModalForm, Label, TextInput
from endstone.block import Block

from .DatabaseManager import DatabaseManager
from .InventoryManager import InventoryManager
from .LanguageManager import LanguageManager
from .SettingManager import SettingManager
from .PriceManager import PriceManager


class ARCButtonShopPlugin(Plugin):
    prefix = "ARCButtonShopPlugin"
    api_version = "0.10"
    load = "POSTWORLD"

    commands = {
        "shop": {
            "description": "Open button shop interface",
            "usages": ["/shop"],
            "permissions": ["arc_button_shop.command.shop"],
        },
        "shopmanage": {
            "description": "Manage button shops, op only.",
            "usages": ["/shopmanage"]
        }
    }

    permissions = {
        "arc_button_shop.command.shop": {
            "description": "Allow users to access shop interface",
            "default": True
        }
    }

    def __init__(self):
        super().__init__()
        self.setting_shop_player = {}  # 玩家名 -> 商店设置数据
        self.CHUNK_SIZE = 16  # 区块大小，用于优化查询
    
    def _safe_log(self, level: str, message: str):
        """
        安全的日志记录方法，在logger未初始化时使用print
        :param level: 日志级别 (info, warning, error)
        :param message: 日志消息
        """
        if hasattr(self, 'logger') and self.logger is not None:
            if level.lower() == 'info':
                self.logger.info(message)
            elif level.lower() == 'warning':
                self.logger.warning(message)
            elif level.lower() == 'error':
                self.logger.error(message)
            else:
                self.logger.info(message)
        else:
            # 如果logger未初始化，使用print
            print(f"[{level.upper()}] {message}")

    def on_load(self) -> None:
        self._safe_log('info', "[ARCButtonShop] on_load is called!")
        
        # 初始化语言管理器
        self.language_manager = LanguageManager("CN")
        
        # 初始化设置管理器
        self.setting_manager = SettingManager()
        
        # 初始化背包管理类（复用附魔/物品匹配等逻辑）
        self.inventory_manager = InventoryManager(self)
        
        # 初始化默认配置
        self._init_default_settings()
        
        # 初始化数据库管理器
        db_path = os.path.join("plugins", "ARCButtonShop", "button_shop.db")
        self.db_manager = DatabaseManager(db_path)
        
        # 创建商店相关表
        self._create_shop_tables()
        
        # 初始化价格管理器（官方定价系统）
        self.price_manager = PriceManager(self)
        self.price_manager.load_price_adjustments_from_db(self.db_manager)

    def on_enable(self) -> None:
        self._safe_log('info', "[ARCButtonShop] on_enable is called!")
        self.register_events(self)

        # 初始化经济插件 - 检查 arc_core 优先，然后 umoney
        self._init_economy_plugin()

        # 注册定时任务
        self._register_scheduled_tasks()

    def on_disable(self) -> None:
        self._safe_log('info', "[ARCButtonShop] on_disable is called!")
        
        # 取消所有定时任务
        self._cancel_scheduled_tasks()
        
        # 关闭数据库连接
        if hasattr(self, 'db_manager'):
            self.db_manager.close()

    # ==================== 定时任务 ====================

    def _register_scheduled_tasks(self):
        """注册所有定时任务"""
        try:
            scheduler = self.server.scheduler
            # 每日波动 - 延迟1分钟后首次检查，之后每24小时(1728000tick)执行一次
            self._daily_task = scheduler.run_task(
                self, self._daily_fluctuation_task, delay=1200, period=1728000
            )
            self._safe_log('info', f"[ARCButtonShop] Daily fluctuation task registered (id={self._daily_task.task_id})")

            # 价格恢复 - 每1分钟(1200tick)执行一次
            self._recovery_task = scheduler.run_task(
                self, self._price_recovery_task, delay=0, period=1200
            )
            self._safe_log('info', f"[ARCButtonShop] Price recovery task registered (id={self._recovery_task.task_id})")

            # 过期清理 - 延迟5分钟后首次执行，之后每24小时执行一次
            self._cleanup_task = scheduler.run_task(
                self, self._cleanup_task_handler, delay=6000, period=1728000
            )
            self._safe_log('info', f"[ARCButtonShop] Cleanup task registered (id={self._cleanup_task.task_id})")

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to register scheduled tasks: {e}")

    def _cancel_scheduled_tasks(self):
        """取消所有定时任务"""
        try:
            scheduler = self.server.scheduler
            scheduler.cancel_tasks(self)
            self._safe_log('info', "[ARCButtonShop] All scheduled tasks cancelled")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to cancel scheduled tasks: {e}")

    def _daily_fluctuation_task(self):
        """每日波动定时任务"""
        try:
            if hasattr(self, 'price_manager') and hasattr(self, 'db_manager'):
                self.price_manager.check_and_apply_daily_fluctuation(self.db_manager)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Daily fluctuation task error: {e}")

    def _price_recovery_task(self):
        """价格恢复定时任务（每分钟）"""
        try:
            if hasattr(self, 'price_manager') and hasattr(self, 'db_manager'):
                self.price_manager.apply_price_recovery(self.db_manager)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Price recovery task error: {e}")

    def _cleanup_task_handler(self):
        """过期数据清理定时任务"""
        try:
            if hasattr(self, 'price_manager') and hasattr(self, 'db_manager'):
                self.price_manager.cleanup_old_trade_volumes(self.db_manager, days=7)
                self._safe_log('info', "[ARCButtonShop] Old trade volumes cleaned up")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Cleanup task error: {e}")
    
    def _init_default_settings(self) -> None:
        """初始化默认配置"""
        # 交易税率 (默认5%)
        tax_rate = self.setting_manager.GetSetting("trade_tax_rate")
        if tax_rate is None:
            self.setting_manager.SetSetting("trade_tax_rate", "0.05")
            self._safe_log('info', "[ARCButtonShop] Set default trade tax rate: 5%")
        
        # 最大商店数量限制 (默认50)
        max_shops = self.setting_manager.GetSetting("max_shops_per_player")
        if max_shops is None:
            self.setting_manager.SetSetting("max_shops_per_player", "50")
            self._safe_log('info', "[ARCButtonShop] Set default max shops per player: 50")
        
        # 是否启用交易税 (默认启用)
        tax_enabled = self.setting_manager.GetSetting("trade_tax_enabled")
        if tax_enabled is None:
            self.setting_manager.SetSetting("trade_tax_enabled", "true")
            self._safe_log('info', "[ARCButtonShop] Trade tax enabled by default")

    def _init_economy_plugin(self) -> None:
        """初始化经济插件 - 检查 arc_core 优先，然后 umoney"""
        try:
            self.economy_plugin = self.server.plugin_manager.get_plugin('arc_core')
            if self.economy_plugin is not None:
                self._safe_log('info', "[ARCButtonShop] Using ARC Core economy system for money rewards.")
            else:
                self.economy_plugin = self.server.plugin_manager.get_plugin('umoney')
                if self.economy_plugin is not None:
                    self._safe_log('info', "[ARCButtonShop] Using UMoney economy system for money rewards.")
                else:
                    self._safe_log('warning', "[ARCButtonShop] No supported economy plugin found (arc_core or umoney). Money rewards will not be available.")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to load economy plugin: {e}. Money rewards will not be available.")

    def _get_player_money(self, player_name: str) -> int:
        """获取玩家金钱数量"""
        if not self.economy_plugin:
            return 0
        
        try:
            return self.economy_plugin.api_get_player_money(player_name)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to get player money for {player_name}: {e}")
        
        return 0

    def _change_player_money(self, player_name: str, amount: int) -> bool:
        """改变玩家金钱数量"""
        if not self.economy_plugin:
            return False
        
        try:
            return self.economy_plugin.api_change_player_money(player_name, amount)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to change player money for {player_name}: {e}")
        
        return False

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        match command.name:
            case "shop":
                if hasattr(sender, 'location') and hasattr(sender, 'send_form'):
                    self._show_shop_main_panel(sender)
                else:
                    sender.send_message(self.language_manager.GetText("PLAYER_ONLY_COMMAND"))
            case "shopmanage":
                return self._handle_shop_manage_command(sender, args)
        return True
    
    # 数据库
    def _create_shop_tables(self) -> None:
        """创建商店相关数据表"""
        
        # 创建商店表
        shop_fields = {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "shop_uuid": "TEXT NOT NULL UNIQUE",  # 商店唯一标识
            "owner_xuid": "TEXT NOT NULL",  # 店主XUID（主要标识符）
            "owner_name": "TEXT NOT NULL",  # 店主名称（用于显示）
            "shop_type": "TEXT NOT NULL DEFAULT 'sell'",  # 商店类型：'sell'出售, 'buy'收购
            "x": "INTEGER NOT NULL",  # 按钮X坐标
            "y": "INTEGER NOT NULL",  # 按钮Y坐标
            "z": "INTEGER NOT NULL",  # 按钮Z坐标
            "dimension": "TEXT NOT NULL",  # 维度
            "chunk_x": "INTEGER NOT NULL",  # 区块X坐标（用于优化查询）
            "chunk_z": "INTEGER NOT NULL",  # 区块Z坐标（用于优化查询）
            "item_type": "TEXT NOT NULL",  # 物品类型
            "item_data": "TEXT NOT NULL",  # 物品数据（JSON格式）
            "quantity": "INTEGER NOT NULL",  # 商品数量
            "unit_price": "REAL NOT NULL",  # 单价
            "stock": "INTEGER NOT NULL",  # 库存（出售商店为剩余库存，收购商店为资金余额）
            "collected_items": "TEXT",  # 收购商店收集的物品（JSON格式）
            "is_active": "INTEGER NOT NULL DEFAULT 1",  # 是否激活
            "create_time": "TEXT NOT NULL",  # 创建时间
            "last_purchase_time": "TEXT",  # 最后购买时间
            "is_infinite": "INTEGER NOT NULL DEFAULT 0"  # 是否无限商店（系统/官方商店）
        }
        
        if self.db_manager.create_table("button_shops", shop_fields):
            self._safe_log('info', "[ARCButtonShop] Button shops table created successfully")
        else:
            self._safe_log('error', "[ARCButtonShop] Failed to create button shops table")
        
        # 创建交易记录表
        transaction_fields = {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "shop_id": "INTEGER NOT NULL",  # 商店ID
            "buyer_xuid": "TEXT NOT NULL",  # 买家XUID（主要标识符）
            "buyer_name": "TEXT NOT NULL",  # 买家名称（用于显示）
            "quantity": "INTEGER NOT NULL",  # 购买数量
            "unit_price": "REAL NOT NULL",  # 购买时的单价
            "total_price": "REAL NOT NULL",  # 总价
            "transaction_time": "TEXT NOT NULL"  # 交易时间
        }
        
        if self.db_manager.create_table("shop_transactions", transaction_fields):
            self._safe_log('info', "[ARCButtonShop] Shop transactions table created successfully")
        else:
            self._safe_log('error', "[ARCButtonShop] Failed to create shop transactions table")
        
        # 创建区块索引表（用于快速查询）
        chunk_index_fields = {
            "chunk_x": "INTEGER NOT NULL",
            "chunk_z": "INTEGER NOT NULL", 
            "dimension": "TEXT NOT NULL",
            "shop_count": "INTEGER NOT NULL DEFAULT 0",
            "PRIMARY KEY": "(chunk_x, chunk_z, dimension)"
        }
        
        if self.db_manager.create_table("chunk_index", chunk_index_fields):
            self._safe_log('info', "[ARCButtonShop] Chunk index table created successfully")
        else:
            self._safe_log('error', "[ARCButtonShop] Failed to create chunk index table")

        # 创建交易量追踪表（用于动态定价）
        trade_volume_fields = {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "item_type": "TEXT NOT NULL",  # 物品类型
            "trade_type": "TEXT NOT NULL",  # 交易类型：'sell'玩家购买, 'buy'玩家出售
            "quantity": "INTEGER NOT NULL",  # 交易数量
            "trade_time": "TEXT NOT NULL"  # 交易时间
        }
        
        if self.db_manager.create_table("item_trade_volume", trade_volume_fields):
            self._safe_log('info', "[ARCButtonShop] Item trade volume table created successfully")
        else:
            self._safe_log('error', "[ARCButtonShop] Failed to create item trade volume table")
        
        # 创建价格调整表（用于动态定价和每日波动）
        price_adjustment_fields = {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "item_type": "TEXT NOT NULL UNIQUE",  # 物品类型
            "demand_sell_adjust": "REAL NOT NULL DEFAULT 0",  # 需求驱动的出售价调整（正数=涨价）
            "demand_buy_adjust": "REAL NOT NULL DEFAULT 0",  # 需求驱动的回收价调整（负数=降价）
            "daily_adjust_percent": "REAL NOT NULL DEFAULT 0",  # 每日波动百分比
            "last_updated": "TEXT NOT NULL"  # 最后更新时间
        }
        
        if self.db_manager.create_table("price_adjustments", price_adjustment_fields):
            self._safe_log('info', "[ARCButtonShop] Price adjustments table created successfully")
        else:
            self._safe_log('error', "[ARCButtonShop] Failed to create price adjustments table")

        # 迁移：为已有表添加 is_infinite 列（若不存在）
        self._migrate_add_is_infinite_column()
        
        # 迁移：为已有表添加 pricing_mode 和 discount_percent 列（若不存在）
        self._migrate_add_pricing_columns()

    def _migrate_add_is_infinite_column(self) -> None:
        """为 button_shops 表添加 is_infinite 列（兼容旧数据库）"""
        try:
            rows = self.db_manager.query_all("PRAGMA table_info(button_shops)")
            if rows is None:
                return
            column_names = [row['name'] for row in rows]
            if 'is_infinite' not in column_names:
                self.db_manager.execute(
                    "ALTER TABLE button_shops ADD COLUMN is_infinite INTEGER NOT NULL DEFAULT 0"
                )
                self._safe_log('info', "[ARCButtonShop] Migrated: added is_infinite column to button_shops")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Migrate is_infinite column error: {str(e)}")

    def _migrate_add_pricing_columns(self) -> None:
        """为 button_shops 表添加 pricing_mode 和 discount_percent 列（兼容旧数据库）"""
        try:
            rows = self.db_manager.query_all("PRAGMA table_info(button_shops)")
            if rows is None:
                return
            column_names = [row['name'] for row in rows]
            if 'pricing_mode' not in column_names:
                self.db_manager.execute(
                    "ALTER TABLE button_shops ADD COLUMN pricing_mode TEXT NOT NULL DEFAULT 'manual'"
                )
                self._safe_log('info', "[ARCButtonShop] Migrated: added pricing_mode column to button_shops")
            if 'discount_percent' not in column_names:
                self.db_manager.execute(
                    "ALTER TABLE button_shops ADD COLUMN discount_percent REAL NOT NULL DEFAULT 0"
                )
                self._safe_log('info', "[ARCButtonShop] Migrated: added discount_percent column to button_shops")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Migrate pricing columns error: {str(e)}")

    # 无限商店库存/预算常量（表示无限）
    UNLIMITED_STOCK = 2147483647

    # 事件监听器
    @event_handler
    def on_player_interact(self, event: PlayerInteractEvent):
        """处理玩家交互事件"""
        try:
            player = event.player
            block = event.block

            # 检查block是否为None
            if block is None:
                return

            # 检查玩家是否处于商店设置状态
            if player.name in self.setting_shop_player:
                if not self._is_button_block(block):
                    # 提示玩家当前交互的不是按钮
                    player.send_message(self.language_manager.GetText("SHOP_NOT_BUTTON").format(block.type))
                    return
                else:
                    self._handle_shop_creation(player, block)
                    event.is_cancelled = True
                return
            else:
                # 检查是否是按钮交互
                if not self._is_button_block(block):
                    return
                
                # 通过区块索引快速检查该位置是否有商店
                shop_data = self._get_shop_at_position_optimized(block.x, block.y, block.z, block.dimension.name)
                if shop_data:
                    self._show_shop_detail_panel(player, shop_data)
                    event.is_cancelled = True
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Player interact error: {str(e)}")

    @event_handler
    def on_block_break(self, event: BlockBreakEvent):
        """处理方块破坏事件（商店保护）"""
        try:
            player = event.player
            block = event.block
            
            # 检查block是否为None
            if block is None:
                return
            
            # 检查是否是按钮破坏
            if not self._is_button_block(block):
                return
            
            # 检查该位置是否有商店
            shop_data = self._get_shop_at_position_optimized(block.x, block.y, block.z, block.dimension.name)
            if not shop_data:
                return  # 没有商店，允许正常破坏
            
            # 检查商店是否有效
            if not shop_data['is_active']:
                return  # 商店已失效，允许破坏
            
            # 检查是否是店主或OP
            is_owner = str(player.unique_id) == shop_data['owner_xuid']
            is_op = getattr(player, 'is_op', False)
            if is_owner or is_op:
                # 店主或OP破坏按钮，显示删除确认面板
                self._show_break_delete_confirm_panel(player, shop_data)
                event.is_cancelled = True
                return
            else:
                # 非店主破坏按钮，阻止破坏并提示
                player.send_message(self.language_manager.GetText("SHOP_BREAK_PROTECTED").format(shop_data['owner_name']))
                event.is_cancelled = True
                return
                
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Block break error: {str(e)}")

    # 商店管理系统
    def _show_shop_main_panel(self, player):
        """显示商店主面板"""
        try:
            main_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_MAIN_PANEL_TITLE"),
                content=self.language_manager.GetText("SHOP_MAIN_PANEL_CONTENT")
            )
            
            # 创建商店按钮
            main_panel.add_button(
                self.language_manager.GetText("SHOP_CREATE_BUTTON"),
                on_click=lambda sender: self._show_shop_type_selection_panel(sender)
            )
            
            # 我的商店按钮
            main_panel.add_button(
                self.language_manager.GetText("SHOP_MY_SHOPS_BUTTON"),
                on_click=lambda sender: self._show_my_shops_panel(sender)
            )
            
            # OP 专属：管理全部商店
            if getattr(player, 'is_op', False):
                main_panel.add_button(
                    self.language_manager.GetText("SHOP_MANAGE_ALL_SHOPS_BUTTON"),
                    on_click=lambda sender: self._show_all_shops_panel(sender)
                )
            
            # 附近商店按钮
            main_panel.add_button(
                self.language_manager.GetText("SHOP_NEARBY_BUTTON"), 
                on_click=lambda sender: self._show_nearby_shops_panel(sender)
            )
            
            # 关闭按钮
            main_panel.add_button(
                self.language_manager.GetText("SHOP_CLOSE_BUTTON"),
                on_click=lambda sender: None
            )
            
            player.send_form(main_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show main panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _show_shop_type_selection_panel(self, player):
        """显示商店类型选择面板（OP 可选无限出售/无限收购作为系统商店）"""
        try:
            type_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_TYPE_SELECT_TITLE"),
                content=self.language_manager.GetText("SHOP_TYPE_SELECT_CONTENT")
            )
            
            # 出售商店按钮
            type_panel.add_button(
                self.language_manager.GetText("SHOP_TYPE_SELL_BUTTON"),
                on_click=lambda sender: self._show_item_selection_panel(sender, "sell")
            )
            
            # 收购商店按钮
            type_panel.add_button(
                self.language_manager.GetText("SHOP_TYPE_BUY_BUTTON"),
                on_click=lambda sender: self._show_item_selection_panel(sender, "buy")
            )
            
            # OP 专属：无限出售（系统商店）、无限收购（系统商店）
            if getattr(player, 'is_op', False):
                type_panel.add_button(
                    self.language_manager.GetText("SHOP_TYPE_SELL_INFINITE_BUTTON"),
                    on_click=lambda sender: self._show_item_selection_panel(sender, "sell_infinite")
                )
                type_panel.add_button(
                    self.language_manager.GetText("SHOP_TYPE_BUY_INFINITE_BUTTON"),
                    on_click=lambda sender: self._show_item_selection_panel(sender, "buy_infinite")
                )
                # 官方定价模式：从配置文件选物品，支持动态定价
                type_panel.add_button(
                    self.language_manager.GetText("SHOP_TYPE_OFFICIAL_SELL_BUTTON"),
                    on_click=lambda sender: self._show_official_price_item_selection(sender, "sell")
                )
                type_panel.add_button(
                    self.language_manager.GetText("SHOP_TYPE_OFFICIAL_BUY_BUTTON"),
                    on_click=lambda sender: self._show_official_price_item_selection(sender, "buy")
                )
            
            # 返回按钮
            type_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_main_panel(sender)
            )
            
            player.send_form(type_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show shop type selection panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _show_item_selection_panel(self, player, shop_type="sell"):
        """显示物品选择面板"""
        try:
            # 获取玩家背包中的物品
            inventory_items = self.inventory_manager.get_inventory_items(player)
            
            if not inventory_items:
                no_items_panel = ActionForm(
                    title=self.language_manager.GetText("SHOP_ITEM_SELECT_TITLE"),
                    content=self.language_manager.GetText("SHOP_NO_ITEMS")
                )
                no_items_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_main_panel(sender)
                )
                player.send_form(no_items_panel)
                return
            
            # 创建物品选择面板
            item_select_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_ITEM_SELECT_TITLE"),
                content=self.language_manager.GetText("SHOP_ITEM_SELECT_CONTENT")
            )
            
            # 为每个物品添加按钮
            for item_info in inventory_items:
                item_name = item_info['name']
                item_count = item_info['count']
                
                # 构建按钮文本，包含附魔和Lore信息
                button_text = f"{item_name} x{item_count}"
                
                # 添加附魔信息
                if item_info.get('enchants'):
                    button_text += f" §b[{self.language_manager.GetText('SHOP_ENCHANT_TAG')}]"
                
                # 添加Lore信息
                if item_info.get('lore'):
                    button_text += f" §d[{self.language_manager.GetText('SHOP_LORE_TAG')}]"
                
                item_select_panel.add_button(
                    button_text,
                    on_click=lambda sender, item=item_info: self._show_price_setting_panel(sender, item, shop_type)
                )
            
            # 返回按钮
            item_select_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_main_panel(sender)
            )
            
            player.send_form(item_select_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show item selection panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _show_price_setting_panel(self, player, item_info, shop_type="sell"):
        """显示价格设置面板（支持 sell/buy/sell_infinite/buy_infinite）"""
        try:
            controls = []
            is_infinite = shop_type in ("sell_infinite", "buy_infinite")
            base_type = "sell" if shop_type in ("sell", "sell_infinite") else "buy"
            
            if shop_type in ("sell", "sell_infinite"):
                # 出售商店（含无限出售）
                item_info_text = self.language_manager.GetText("SHOP_PRICE_SELL_ITEM_INFO").format(item_info['name'], item_info['count'])
                if is_infinite:
                    item_info_text += "\n" + self.language_manager.GetText("SHOP_INFINITE_SELL_TAG")
                if item_info.get('enchants'):
                    item_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANTS")
                    for enchant_id, level in item_info['enchants'].items():
                        item_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANT_LINE").format(enchant_id, level)
                if item_info.get('lore'):
                    item_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_LORE")
                    for lore_line in item_info['lore']:
                        item_info_text += "\n  " + lore_line
                item_label = Label(text=item_info_text)
                controls.append(item_label)
                price_input = TextInput(
                    label=self.language_manager.GetText("SHOP_PRICE_INPUT_LABEL"),
                    placeholder=self.language_manager.GetText("SHOP_PRICE_INPUT_PLACEHOLDER"),
                    default_value="10"
                )
                controls.append(price_input)
                
            else:  # buy 或 buy_infinite
                # 收购商店（含无限收购）
                buy_info_text = self.language_manager.GetText("SHOP_PRICE_BUY_ITEM_INFO").format(item_info['name'])
                if is_infinite:
                    buy_info_text += "\n" + self.language_manager.GetText("SHOP_INFINITE_BUY_TAG")
                if item_info.get('enchants'):
                    buy_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANTS")
                    for enchant_id, level in item_info['enchants'].items():
                        buy_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANT_LINE").format(enchant_id, level)
                if item_info.get('lore'):
                    buy_info_text += "\n" + self.language_manager.GetText("SHOP_MANAGE_LORE")
                    for lore_line in item_info['lore']:
                        buy_info_text += "\n  " + lore_line
                buy_label = Label(text=buy_info_text)
                controls.append(buy_label)
                price_input = TextInput(
                    label=self.language_manager.GetText("SHOP_BUY_PRICE_INPUT_LABEL"),
                    placeholder=self.language_manager.GetText("SHOP_BUY_PRICE_INPUT_PLACEHOLDER"),
                    default_value="10"
                )
                controls.append(price_input)
                if not is_infinite:
                    budget_input = TextInput(
                        label=self.language_manager.GetText("SHOP_BUY_BUDGET_LABEL"),
                        placeholder=self.language_manager.GetText("SHOP_BUY_BUDGET_PLACEHOLDER"),
                        default_value="1000"
                    )
                    controls.append(budget_input)
            
            def process_shop_creation(sender, json_str: str):
                try:
                    data = json.loads(json_str)
                    price_str = data[1]
                    try:
                        unit_price = int(float(price_str))
                        if unit_price <= 0:
                            raise ValueError("Price must be positive")
                    except ValueError:
                        result_form = ActionForm(
                            title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                            content=self.language_manager.GetText("SHOP_INVALID_PRICE")
                        )
                        result_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_price_setting_panel(s, item_info, shop_type)
                        )
                        sender.send_form(result_form)
                        return
                    
                    budget = 0
                    if base_type == "buy" and not is_infinite:
                        budget_str = data[2]
                        try:
                            budget = int(float(budget_str))
                            if budget <= 0:
                                raise ValueError("Budget must be positive")
                            if budget < unit_price:
                                raise ValueError("Budget must be at least equal to unit price")
                        except ValueError:
                            result_form = ActionForm(
                                title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                                content=self.language_manager.GetText("SHOP_INVALID_BUDGET")
                            )
                            result_form.add_button(
                                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                                on_click=lambda s: self._show_price_setting_panel(s, item_info, shop_type)
                            )
                            sender.send_form(result_form)
                            return
                        player_money = self._get_player_money(sender.name)
                        if player_money < int(budget):
                            result_form = ActionForm(
                                title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                                content=self.language_manager.GetText("SHOP_INSUFFICIENT_FUNDS_FOR_BUDGET").format(int(budget), player_money)
                            )
                            result_form.add_button(
                                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                                on_click=lambda s: self._show_price_setting_panel(s, item_info, shop_type)
                            )
                            sender.send_form(result_form)
                            return
                    
                    shop_data = {
                        'item_info': item_info,
                        'unit_price': unit_price,
                        'shop_type': base_type,
                        'budget': budget,
                        'is_infinite': is_infinite,
                        'create_time': datetime.datetime.now()
                    }
                    self.setting_shop_player[sender.name] = shop_data
                    
                    if base_type == "sell":
                        instruction_content = self.language_manager.GetText("SHOP_SETUP_INSTRUCTION").format(
                            item_info['name'], item_info['count'], unit_price
                        ).replace('\\n', '\n')
                    else:
                        instruction_content = self.language_manager.GetText("SHOP_BUY_SETUP_INSTRUCTION").format(
                            item_info['name'], unit_price, int(budget), int(budget / unit_price) if budget else "∞"
                        ).replace('\\n', '\n')
                    if is_infinite:
                        instruction_content += "\n\n" + self.language_manager.GetText("SHOP_INFINITE_SETUP_HINT")
                    instruction_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_SETUP_TITLE"),
                        content=instruction_content,
                        on_close=lambda s: None
                    )
                    sender.send_form(instruction_form)
                    
                except Exception as e:
                    self._safe_log('error', f"[ARCButtonShop] Process shop creation error: {str(e)}")
                    error_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                        content=self.language_manager.GetText("SHOP_PANEL_ERROR")
                    )
                    error_form.add_button(
                        self.language_manager.GetText("SHOP_BACK_BUTTON"),
                        on_click=lambda s: self._show_shop_main_panel(s)
                    )
                    sender.send_form(error_form)
            
            title = self.language_manager.GetText("SHOP_BUY_PRICE_PANEL_TITLE" if base_type == "buy" else "SHOP_PRICE_PANEL_TITLE")
            if is_infinite:
                title = self.language_manager.GetText("SHOP_INFINITE_TITLE_PREFIX") + title
            price_panel = ModalForm(
                title=title,
                controls=controls,
                on_submit=process_shop_creation
            )
            
            player.send_form(price_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show price setting panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    # ==================== 官方定价模式 ====================

    def _show_official_price_item_selection(self, player, shop_type="sell"):
        """显示官方定价物品选择面板（从配置文件选物品）"""
        try:
            priced_items = self.price_manager.get_all_priced_items()
            if not priced_items:
                no_items_panel = ActionForm(
                    title=self.language_manager.GetText("SHOP_OFFICIAL_PRICE_TITLE"),
                    content=self.language_manager.GetText("SHOP_OFFICIAL_NO_ITEMS")
                )
                no_items_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_type_selection_panel(sender)
                )
                player.send_form(no_items_panel)
                return

            content_text = self.language_manager.GetText("SHOP_OFFICIAL_SELECT_CONTENT_SELL") if shop_type == "sell" else self.language_manager.GetText("SHOP_OFFICIAL_SELECT_CONTENT_BUY")
            item_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_OFFICIAL_PRICE_TITLE"),
                content=content_text
            )

            for item_type, prices in priced_items.items():
                display_name = self.price_manager.get_item_display_name(item_type)
                if shop_type == "sell":
                    price = prices.get('sell', 0)
                    # 显示动态价格
                    final_price = self.price_manager.calculate_final_price(item_type, 'sell', 0)
                    adj = self.price_manager.get_price_adjustment(item_type)
                    price_text = f"{price}"
                    if adj['daily_adjust_percent'] != 0 or adj['demand_sell_adjust'] != 0:
                        price_text = f"{final_price}({price})"
                    button_text = f"{display_name} - {self.language_manager.GetText('SHOP_OFFICIAL_SELL_PRICE')}{price_text}"
                else:
                    price = prices.get('buy', 0)
                    final_price = self.price_manager.calculate_final_price(item_type, 'buy', 0)
                    adj = self.price_manager.get_price_adjustment(item_type)
                    price_text = f"{price}"
                    if adj['daily_adjust_percent'] != 0 or adj['demand_buy_adjust'] != 0:
                        price_text = f"{final_price}({price})"
                    button_text = f"{display_name} - {self.language_manager.GetText('SHOP_OFFICIAL_BUY_PRICE')}{price_text}"

                item_panel.add_button(
                    button_text,
                    on_click=lambda sender, it=item_type, pr=prices: self._show_official_discount_panel(sender, it, pr, shop_type)
                )

            item_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_type_selection_panel(sender)
            )

            player.send_form(item_panel)

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show official price item selection error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _show_official_discount_panel(self, player, item_type, prices, shop_type="sell"):
        """显示官方定价折扣设置面板"""
        try:
            display_name = self.price_manager.get_item_display_name(item_type)
            base_price = prices.get('sell', 0) if shop_type == "sell" else prices.get('buy', 0)
            final_price = self.price_manager.calculate_final_price(item_type, shop_type, 0)
            adj = self.price_manager.get_price_adjustment(item_type)

            # 构建价格信息
            if shop_type == "sell":
                info_text = self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_INFO_SELL").format(
                    display_name, base_price, final_price
                )
            else:
                info_text = self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_INFO_BUY").format(
                    display_name, base_price, final_price
                )

            # 显示动态定价信息
            if adj['demand_sell_adjust'] != 0 or adj['demand_buy_adjust'] != 0:
                if shop_type == "sell" and adj['demand_sell_adjust'] != 0:
                    info_text += "\n" + self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(
                        f"{adj['demand_sell_adjust']:+.1%}"
                    )
                elif shop_type == "buy" and adj['demand_buy_adjust'] != 0:
                    info_text += "\n" + self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(
                        f"{adj['demand_buy_adjust']:+.1%}"
                    )

            if adj['daily_adjust_percent'] != 0:
                info_text += "\n" + self.language_manager.GetText("SHOP_OFFICIAL_DAILY_FLUCTUATION").format(
                    f"{adj['daily_adjust_percent']:+.1f}%"
                )

            info_label = Label(text=info_text)
            discount_input = TextInput(
                label=self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_LABEL"),
                placeholder=self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_PLACEHOLDER"),
                default_value="0"
            )

            def process_official_shop_creation(sender, json_str: str):
                try:
                    data = json.loads(json_str)
                    discount_str = data[1]
                    try:
                        discount_percent = float(discount_str)
                        if discount_percent < -90 or discount_percent > 100:
                            raise ValueError("Discount out of range")
                    except ValueError:
                        result_form = ActionForm(
                            title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                            content=self.language_manager.GetText("SHOP_OFFICIAL_INVALID_DISCOUNT")
                        )
                        result_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_official_discount_panel(s, item_type, prices, shop_type)
                        )
                        sender.send_form(result_form)
                        return

                    # 计算最终价格
                    calculated_price = self.price_manager.calculate_final_price(item_type, shop_type, discount_percent)
                    if calculated_price is None or calculated_price <= 0:
                        result_form = ActionForm(
                            title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                            content=self.language_manager.GetText("SHOP_OFFICIAL_PRICE_ERROR")
                        )
                        result_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_official_discount_panel(s, item_type, prices, shop_type)
                        )
                        sender.send_form(result_form)
                        return

                    # 构造物品信息（官方定价模式不需要从背包取物品）
                    item_info = {
                        'type': item_type,
                        'name': display_name,
                        'count': 1,
                        'data': 0,
                        'enchants': {},
                        'lore': []
                    }

                    shop_data = {
                        'item_info': item_info,
                        'unit_price': calculated_price,
                        'shop_type': shop_type,
                        'budget': 0,
                        'is_infinite': True,
                        'pricing_mode': 'official',
                        'discount_percent': discount_percent,
                        'create_time': datetime.datetime.now()
                    }
                    self.setting_shop_player[sender.name] = shop_data

                    # 显示设置说明
                    discount_text = f" ({discount_percent:+.0f}%)" if discount_percent != 0 else ""
                    if shop_type == "sell":
                        instruction_content = self.language_manager.GetText("SHOP_OFFICIAL_SETUP_SELL").format(
                            display_name, calculated_price, base_price, discount_text
                        ).replace('\\n', '\n')
                    else:
                        instruction_content = self.language_manager.GetText("SHOP_OFFICIAL_SETUP_BUY").format(
                            display_name, calculated_price, base_price, discount_text
                        ).replace('\\n', '\n')

                    instruction_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_SETUP_TITLE"),
                        content=instruction_content,
                        on_close=lambda s: None
                    )
                    sender.send_form(instruction_form)

                except Exception as e:
                    self._safe_log('error', f"[ARCButtonShop] Process official shop creation error: {str(e)}")
                    error_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                        content=self.language_manager.GetText("SHOP_PANEL_ERROR")
                    )
                    error_form.add_button(
                        self.language_manager.GetText("SHOP_BACK_BUTTON"),
                        on_click=lambda s: self._show_shop_main_panel(s)
                    )
                    sender.send_form(error_form)

            title = self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_TITLE_SELL") if shop_type == "sell" else self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_TITLE_BUY")
            discount_panel = ModalForm(
                title=title,
                controls=[info_label, discount_input],
                on_submit=process_official_shop_creation
            )

            player.send_form(discount_panel)

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show official discount panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _get_shop_display_price(self, shop_data) -> str:
        """获取商店的显示价格（官方定价模式返回动态价格，手动定价返回unit_price）"""
        pricing_mode = shop_data.get('pricing_mode', 'manual')
        if pricing_mode == 'official':
            item_type = shop_data.get('item_type', '')
            shop_type = shop_data.get('shop_type', 'sell')
            discount_percent = float(shop_data.get('discount_percent', 0) or 0)
            final_price = self.price_manager.calculate_final_price(item_type, shop_type, discount_percent)
            if final_price is not None:
                return f"§d{final_price}§r"
        return shop_data.get('unit_price', 0)

    def _is_shop_infinite(self, shop_data) -> bool:
        """判断商店是否为无限商店（系统商店）；兼容 SQLite 中 0/1、字符串等类型"""
        if not shop_data:
            return False
        v = shop_data.get('is_infinite', 0)
        if v is None:
            return False
        if isinstance(v, bool):
            return v
        try:
            return int(v) != 0
        except (TypeError, ValueError):
            return bool(v)

    def _get_shop_owner_display(self, shop_data) -> str:
        """界面显示的「店主」：系统商店为官方，不显示创建者个人名（资金与其无关）"""
        if self._is_shop_infinite(shop_data):
            return self.language_manager.GetText("SHOP_OWNER_SYSTEM")
        return shop_data.get('owner_name', '')

    def _get_shop_type_manage_line(self, shop_data) -> str:
        """管理/详情用：一行说明是出售还是收购（含系统无限说明）"""
        shop_type = shop_data.get('shop_type', 'sell')
        is_infinite = self._is_shop_infinite(shop_data)
        pricing_mode = shop_data.get('pricing_mode', 'manual')
        if pricing_mode == 'official':
            if shop_type == 'sell':
                return self.language_manager.GetText("SHOP_TYPE_MANAGE_SELL_OFFICIAL")
            return self.language_manager.GetText("SHOP_TYPE_MANAGE_BUY_OFFICIAL")
        if shop_type == 'sell':
            if is_infinite:
                return self.language_manager.GetText("SHOP_TYPE_MANAGE_SELL_INFINITE")
            return self.language_manager.GetText("SHOP_TYPE_MANAGE_SELL")
        if is_infinite:
            return self.language_manager.GetText("SHOP_TYPE_MANAGE_BUY_INFINITE")
        return self.language_manager.GetText("SHOP_TYPE_MANAGE_BUY")

    def _get_shop_type_short_tag(self, shop_data) -> str:
        """列表按钮用短标签：出售 / 收购"""
        shop_type = shop_data.get('shop_type', 'sell')
        is_infinite = self._is_shop_infinite(shop_data)
        pricing_mode = shop_data.get('pricing_mode', 'manual')
        if pricing_mode == 'official':
            if shop_type == 'sell':
                return self.language_manager.GetText("SHOP_TYPE_TAG_SELL_OFFICIAL")
            return self.language_manager.GetText("SHOP_TYPE_TAG_BUY_OFFICIAL")
        if shop_type == 'sell':
            return self.language_manager.GetText("SHOP_TYPE_TAG_SELL_INFINITE") if is_infinite else self.language_manager.GetText("SHOP_TYPE_TAG_SELL")
        return self.language_manager.GetText("SHOP_TYPE_TAG_BUY_INFINITE") if is_infinite else self.language_manager.GetText("SHOP_TYPE_TAG_BUY")

    def _get_shop_type_plain_headline(self, shop_data) -> str:
        """管理面板顶部用：无 § 色码，避免部分客户端正文里看不清类型"""
        shop_type = shop_data.get('shop_type', 'sell')
        is_infinite = self._is_shop_infinite(shop_data)
        pricing_mode = shop_data.get('pricing_mode', 'manual')
        if pricing_mode == 'official':
            official_tag = self.language_manager.GetText("SHOP_TYPE_PLAIN_OFFICIAL_TAG")
            if shop_type == 'sell':
                return self.language_manager.GetText("SHOP_TYPE_PLAIN_SELL").format(official_tag)
            return self.language_manager.GetText("SHOP_TYPE_PLAIN_BUY").format(official_tag)
        sys_tag = self.language_manager.GetText("SHOP_TYPE_PLAIN_SYSTEM_TAG") if is_infinite else ""
        if shop_type == 'sell':
            return self.language_manager.GetText("SHOP_TYPE_PLAIN_SELL").format(sys_tag)
        return self.language_manager.GetText("SHOP_TYPE_PLAIN_BUY").format(sys_tag)

    def _get_shop_manage_title_suffix(self, shop_data) -> str:
        """表单标题用短后缀，与正文类型一致（窗口标题不易被截断）"""
        shop_type = shop_data.get('shop_type', 'sell')
        is_infinite = self._is_shop_infinite(shop_data)
        pricing_mode = shop_data.get('pricing_mode', 'manual')
        if pricing_mode == 'official':
            if shop_type == 'sell':
                return self.language_manager.GetText("SHOP_MANAGE_TITLE_SELL_OFFICIAL")
            return self.language_manager.GetText("SHOP_MANAGE_TITLE_BUY_OFFICIAL")
        if shop_type == 'sell':
            return self.language_manager.GetText("SHOP_MANAGE_TITLE_SELL_INFINITE") if is_infinite else self.language_manager.GetText("SHOP_MANAGE_TITLE_SELL")
        return self.language_manager.GetText("SHOP_MANAGE_TITLE_BUY_INFINITE") if is_infinite else self.language_manager.GetText("SHOP_MANAGE_TITLE_BUY")

    def _shop_item_transaction_payload(self, item_data: dict, count: int) -> dict:
        """从商店 JSON item_data 构造背包校验/发放用的完整字段（含 NBT，避免丢失附魔书等标签）。"""
        payload = {
            'type': item_data['type'],
            'name': item_data.get('name', item_data['type']),
            'count': count,
            'data': item_data.get('data', 0),
            'enchants': item_data.get('enchants') or {},
            'lore': item_data.get('lore') or [],
        }
        nbt_b64 = item_data.get('nbt_b64')
        if nbt_b64:
            payload['nbt_b64'] = nbt_b64
        return payload

    def _show_shop_detail_panel(self, player, shop_data):
        """显示商店详情面板"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            
            shop_info = self.language_manager.GetText("SHOP_DETAIL_OWNER").format(self._get_shop_owner_display(shop_data)) + "\n"
            shop_info += self.language_manager.GetText("SHOP_DETAIL_TYPE").format(self._get_shop_type_plain_headline(shop_data)) + "\n"
            shop_info += self._get_shop_type_manage_line(shop_data) + "\n"
            shop_info += self.language_manager.GetText("SHOP_DETAIL_ITEM").format(item_data.get('name', 'Unknown')) + "\n"
            if is_infinite:
                shop_info += (self.language_manager.GetText("SHOP_DETAIL_STOCK").format(self.language_manager.GetText("SHOP_DETAIL_INFINITE_STOCK")) + "\n") if shop_type == "sell" else (self.language_manager.GetText("SHOP_DETAIL_BUDGET").format(self.language_manager.GetText("SHOP_DETAIL_INFINITE_BUDGET")) + "\n")
            else:
                shop_info += (self.language_manager.GetText("SHOP_DETAIL_STOCK").format(shop_data['stock']) + "\n") if shop_type == "sell" else (self.language_manager.GetText("SHOP_DETAIL_BUDGET").format(shop_data['stock']) + "\n")
            shop_info += self.language_manager.GetText("SHOP_DETAIL_PRICE").format(shop_data['unit_price']) + "\n"
            
            # 官方定价模式：显示动态价格信息
            pricing_mode = shop_data.get('pricing_mode', 'manual')
            if pricing_mode == 'official':
                discount_percent = shop_data.get('discount_percent', 0.0)
                item_type = shop_data.get('item_type', '')
                display_price = self.price_manager.calculate_final_price(item_type, shop_type, discount_percent)
                if display_price is not None and display_price != shop_data['unit_price']:
                    shop_info += self.language_manager.GetText("SHOP_DETAIL_CURRENT_PRICE").format(display_price) + "\n"
                adj = self.price_manager.get_price_adjustment(item_type)
                base_price = self.price_manager.get_base_price(item_type, shop_type)
                if base_price is not None:
                    shop_info += self.language_manager.GetText("SHOP_DETAIL_BASE_PRICE").format(base_price) + "\n"
                if adj['demand_sell_adjust'] != 0 or adj['demand_buy_adjust'] != 0:
                    if shop_type == 'sell' and adj['demand_sell_adjust'] != 0:
                        shop_info += self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(f"{adj['demand_sell_adjust']:+.1%}") + "\n"
                    elif shop_type == 'buy' and adj['demand_buy_adjust'] != 0:
                        shop_info += self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(f"{adj['demand_buy_adjust']:+.1%}") + "\n"
                if adj['daily_adjust_percent'] != 0:
                    shop_info += self.language_manager.GetText("SHOP_OFFICIAL_DAILY_FLUCTUATION").format(f"{adj['daily_adjust_percent']:+.1f}%") + "\n"
                if discount_percent != 0:
                    shop_info += self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_DISPLAY").format(f"{discount_percent:+.0f}%") + "\n"
            
            # 添加附魔信息
            if item_data.get('enchants'):
                shop_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANTS")
                for enchant_id, level in item_data['enchants'].items():
                    shop_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANT_LINE").format(enchant_id, level)
            
            # 添加Lore信息
            if item_data.get('lore'):
                shop_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_LORE")
                for lore_line in item_data['lore']:
                    shop_info += "\n  " + lore_line
            
            detail_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_DETAIL_TITLE"),
                content=shop_info
            )
            
            # 如果不是店主且有库存（或无限商店），添加购买按钮
            can_trade = (is_infinite or shop_data['stock'] > 0)
            if str(player.unique_id) != shop_data['owner_xuid'] and can_trade:
                if shop_type == "sell":
                    # 出售商店 - 显示购买按钮
                    detail_panel.add_button(
                        self.language_manager.GetText("SHOP_BUY_BUTTON"),
                        on_click=lambda sender: self._show_purchase_panel(sender, shop_data)
                    )
                else:
                    # 收购商店 - 显示出售按钮
                    detail_panel.add_button(
                        self.language_manager.GetText("SHOP_SELL_BUTTON"),
                        on_click=lambda sender: self._show_purchase_panel(sender, shop_data)
                    )
            elif str(player.unique_id) == shop_data['owner_xuid']:
                # 店主管理按钮
                detail_panel.add_button(
                    self.language_manager.GetText("SHOP_MANAGE_BUTTON"),
                    on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data)
                )
            
            # 关闭按钮
            detail_panel.add_button(
                self.language_manager.GetText("SHOP_CLOSE_BUTTON"),
                on_click=lambda sender: None
            )
            
            player.send_form(detail_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show shop detail error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    def _show_purchase_panel(self, player, shop_data):
        """显示购买面板"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            type_headline = f"{self._get_shop_type_plain_headline(shop_data)}\n\n"
            
            # 官方定价模式：使用动态计算价格
            pricing_mode = shop_data.get('pricing_mode', 'manual')
            if pricing_mode == 'official':
                discount_percent = shop_data.get('discount_percent', 0.0)
                item_type = shop_data.get('item_type', '')
                display_price = self.price_manager.calculate_final_price(item_type, shop_type, discount_percent)
                if display_price is None:
                    display_price = shop_data['unit_price']
            else:
                display_price = shop_data['unit_price']
            
            if shop_type == "sell":
                purchase_info = type_headline + self.language_manager.GetText("SHOP_PURCHASE_SELL_INFO").format(item_data.get('name', 'Unknown'), self.language_manager.GetText("SHOP_STOCK_INFINITE") if is_infinite else str(shop_data['stock']), display_price) + "\n"
            else:
                purchase_info = type_headline + self.language_manager.GetText("SHOP_PURCHASE_BUY_INFO").format(item_data.get('name', 'Unknown'), self.language_manager.GetText("SHOP_STOCK_INFINITE") if is_infinite else str(shop_data['stock']), display_price) + "\n"
            
            # 官方定价模式：显示价格组成信息
            if pricing_mode == 'official':
                adj = self.price_manager.get_price_adjustment(item_type)
                base_price = self.price_manager.get_base_price(item_type, shop_type)
                if base_price is not None and display_price != base_price:
                    purchase_info += self.language_manager.GetText("SHOP_OFFICIAL_PRICE_BREAKDOWN").format(base_price, display_price) + "\n"
                if adj['demand_sell_adjust'] != 0 or adj['demand_buy_adjust'] != 0:
                    if shop_type == 'sell' and adj['demand_sell_adjust'] != 0:
                        purchase_info += self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(f"{adj['demand_sell_adjust']:+.1%}") + "\n"
                    elif shop_type == 'buy' and adj['demand_buy_adjust'] != 0:
                        purchase_info += self.language_manager.GetText("SHOP_OFFICIAL_DEMAND_ADJUST").format(f"{adj['demand_buy_adjust']:+.1%}") + "\n"
                if adj['daily_adjust_percent'] != 0:
                    purchase_info += self.language_manager.GetText("SHOP_OFFICIAL_DAILY_FLUCTUATION").format(f"{adj['daily_adjust_percent']:+.1f}%") + "\n"
                if discount_percent != 0:
                    purchase_info += self.language_manager.GetText("SHOP_OFFICIAL_DISCOUNT_DISPLAY").format(f"{discount_percent:+.0f}%") + "\n"
            
            # 添加附魔信息
            if item_data.get('enchants'):
                purchase_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANTS")
                for enchant_id, level in item_data['enchants'].items():
                    purchase_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_ENCHANT_LINE").format(enchant_id, level)
            
            # 添加Lore信息
            if item_data.get('lore'):
                purchase_info += "\n" + self.language_manager.GetText("SHOP_MANAGE_LORE")
                for lore_line in item_data['lore']:
                    purchase_info += "\n  " + lore_line
            
            # 添加税收信息
            tax_rate = self._get_tax_rate()
            if tax_rate > 0:
                tax_percent = int(tax_rate * 100)
                purchase_info += "\n\n" + self.language_manager.GetText("SHOP_TAX_RATE_DISPLAY").format(tax_percent)
            
            item_label = Label(text=purchase_info)
            
            max_quantity = self.UNLIMITED_STOCK if is_infinite else shop_data['stock']
            quantity_placeholder = self.language_manager.GetText("SHOP_STOCK_INFINITE") if is_infinite else str(shop_data['stock'])
            if shop_type == "sell":
                quantity_input = TextInput(
                    label=self.language_manager.GetText("SHOP_QUANTITY_LABEL"),
                    placeholder=quantity_placeholder,
                    default_value="1"
                )
            else:
                quantity_input = TextInput(
                    label=self.language_manager.GetText("SHOP_SELL_QUANTITY_LABEL"),
                    placeholder=quantity_placeholder,
                    default_value="1"
                )
            
            def process_purchase(sender, json_str: str):
                try:
                    data = json.loads(json_str)
                    quantity_str = data[1]
                    try:
                        quantity = int(quantity_str)
                        if quantity <= 0:
                            raise ValueError("Quantity must be positive")
                        if not is_infinite and quantity > shop_data['stock']:
                            raise ValueError("Not enough stock")
                        if shop_type == "buy" and not is_infinite and quantity * display_price > shop_data['stock']:
                            raise ValueError("Not enough budget")
                    except ValueError as e:
                        result_form = ActionForm(
                            title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                            content=self.language_manager.GetText("SHOP_INVALID_QUANTITY")
                        )
                        result_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_purchase_panel(s, shop_data)
                        )
                        sender.send_form(result_form)
                        return
                    
                    # 执行购买
                    success, message = self._execute_purchase(sender, shop_data, quantity)
                    
                    result_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                        content=message,
                        on_close=lambda s: None
                    )
                    sender.send_form(result_form)
                    
                except Exception as e:
                    self._safe_log('error', f"[ARCButtonShop] Process purchase error: {str(e)}")
                    error_form = ActionForm(
                        title=self.language_manager.GetText("SHOP_RESULT_TITLE"),
                        content=self.language_manager.GetText("SHOP_PANEL_ERROR"),
                        on_close=lambda s: None
                    )
                    sender.send_form(error_form)
            
            # 根据商店类型选择标题，并附带类型后缀（与「管理商店」一致）
            if shop_type == "sell":
                panel_title = self.language_manager.GetText("SHOP_PURCHASE_TITLE")
            else:
                panel_title = self.language_manager.GetText("SHOP_SELL_TITLE")
            panel_title = f"{panel_title}{self._get_shop_manage_title_suffix(shop_data)}"
            
            purchase_panel = ModalForm(
                title=panel_title,
                controls=[item_label, quantity_input],
                on_submit=process_purchase
            )
            
            player.send_form(purchase_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show purchase panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_PANEL_ERROR"))

    # 商店操作相关方法
    def _handle_shop_creation(self, player, block):
        """处理商店创建（含无限商店）"""
        try:
            if player.name not in self.setting_shop_player:
                return
            
            shop_data = self.setting_shop_player[player.name]
            item_info = shop_data['item_info']
            unit_price = shop_data['unit_price']
            shop_type = shop_data.get('shop_type', 'sell')
            budget = shop_data.get('budget', 0)
            is_infinite = shop_data.get('is_infinite', False)
            pricing_mode = shop_data.get('pricing_mode', 'manual')
            discount_percent = shop_data.get('discount_percent', 0.0)
            
            # 检查该位置是否已有商店
            existing_shop = self._get_shop_at_position(block.x, block.y, block.z, block.dimension.name)
            if existing_shop:
                player.send_message(self.language_manager.GetText("SHOP_ALREADY_EXISTS"))
                return
            
            if shop_type == "sell":
                if not is_infinite and not self.inventory_manager.has_item(player, item_info):
                    player.send_message(self.language_manager.GetText("SHOP_ITEM_NOT_FOUND"))
                    del self.setting_shop_player[player.name]
                    return
            else:
                if not is_infinite:
                    player_money = self._get_player_money(player.name)
                    if player_money < int(budget):
                        player.send_message(self.language_manager.GetText("SHOP_INSUFFICIENT_FUNDS_FOR_BUDGET").format(int(budget), player_money))
                        del self.setting_shop_player[player.name]
                        return
            
            shop_uuid = self._generate_shop_uuid()
            chunk_x, chunk_z = self._get_chunk_coords(block.x, block.z)
            
            if is_infinite:
                quantity = self.UNLIMITED_STOCK
                stock = self.UNLIMITED_STOCK
            elif shop_type == "sell":
                quantity = item_info['count']
                stock = item_info['count']
            else:
                quantity = int(budget / unit_price)
                stock = int(budget)
            
            new_shop = {
                'shop_uuid': shop_uuid,
                'owner_xuid': str(player.unique_id),
                'owner_name': player.name,
                'shop_type': shop_type,
                'x': block.x,
                'y': block.y,
                'z': block.z,
                'dimension': block.dimension.name,
                'chunk_x': chunk_x,
                'chunk_z': chunk_z,
                'item_type': item_info['type'],
                'item_data': json.dumps(item_info),
                'quantity': quantity,
                'unit_price': int(unit_price),
                'stock': stock,
                'is_infinite': 1 if is_infinite else 0,
                'pricing_mode': pricing_mode,
                'discount_percent': discount_percent,
                'create_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            operation_success = False
            if is_infinite:
                operation_success = True  # 无限商店不扣物品/预算
            elif shop_type == "sell":
                operation_success = self.inventory_manager.remove_item(player, item_info)
                if not operation_success:
                    player.send_message(self.language_manager.GetText("SHOP_ITEM_REMOVE_FAILED"))
            else:
                operation_success = self._change_player_money(player.name, -int(budget))
                if not operation_success:
                    player.send_message(self.language_manager.GetText("SHOP_BUDGET_DEDUCT_FAILED"))
            
            if operation_success:
                # 插入商店数据
                if self.db_manager.insert("button_shops", new_shop):
                    # 更新区块索引
                    self._update_chunk_index(chunk_x, chunk_z, block.dimension.name, 1)
                    
                    if pricing_mode == 'official':
                        player.send_message(self.language_manager.GetText("SHOP_OFFICIAL_CREATED_SUCCESS").format(item_info['name'], unit_price, discount_percent))
                    elif is_infinite:
                        player.send_message(self.language_manager.GetText("SHOP_INFINITE_CREATED_SUCCESS").format(item_info['name'], unit_price))
                    elif shop_type == "sell":
                        player.send_message(self.language_manager.GetText("SHOP_CREATED_SUCCESS").format(
                            item_info['name'], item_info['count'], unit_price
                        ))
                    else:
                        player.send_message(self.language_manager.GetText("SHOP_BUY_CREATED_SUCCESS").format(
                            item_info['name'], unit_price, int(budget), quantity
                        ))
                    self._safe_log('info', f"[ARCButtonShop] Shop created by {player.name} at ({block.x}, {block.y}, {block.z})")
                else:
                    # 如果创建失败，根据商店类型进行回滚（无限商店未扣物品/预算，无需回滚）
                    if not is_infinite:
                        if shop_type == "sell":
                            self.inventory_manager.give_item(player, item_info)
                        else:
                            self._change_player_money(player.name, int(budget))
                    player.send_message(self.language_manager.GetText("SHOP_CREATE_FAILED"))
            else:
                player.send_message(self.language_manager.GetText("SHOP_ITEM_REMOVE_FAILED"))
            
            # 清除设置状态
            del self.setting_shop_player[player.name]
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Handle shop creation error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_CREATE_FAILED"))
            if player.name in self.setting_shop_player:
                del self.setting_shop_player[player.name]

    def _execute_purchase(self, player, shop_data, quantity):
        """执行购买操作（支持出售商店、收购商店和税收）"""
        try:
            shop_type = shop_data.get('shop_type', 'sell')
            pricing_mode = shop_data.get('pricing_mode', 'manual')
            
            # 官方定价模式：使用动态计算价格
            if pricing_mode == 'official':
                discount_percent = shop_data.get('discount_percent', 0.0)
                item_type = shop_data.get('item_type', '')
                final_unit_price = self.price_manager.calculate_final_price(item_type, shop_type, discount_percent)
                if final_unit_price is None:
                    return False, self.language_manager.GetText("SHOP_OFFICIAL_PRICE_ERROR")
                unit_price = final_unit_price
            else:
                unit_price = shop_data['unit_price']
            
            base_price = int(quantity * unit_price)
            tax_amount = self._calculate_tax(base_price)
            total_price = base_price + tax_amount
            
            # 检查经济插件是否可用
            if not self.economy_plugin:
                return False, self.language_manager.GetText("SHOP_CORE_PLUGIN_NOT_FOUND")
            
            # 检查当前商店状态
            current_shop = self._get_shop_by_id(shop_data['id'])
            if not current_shop or not current_shop['is_active']:
                return False, self.language_manager.GetText("SHOP_NOT_AVAILABLE")
            
            # 官方定价模式：记录交易量并更新需求定价
            if pricing_mode == 'official':
                self.price_manager.record_trade_volume(item_type, shop_type, quantity, self.db_manager)
                self.price_manager.update_demand_pricing(item_type, self.db_manager)
            
            if shop_type == "sell":
                return self._execute_sell_shop_purchase(player, current_shop, quantity, base_price, tax_amount, total_price, unit_price)
            else:  # buy
                return self._execute_buy_shop_purchase(player, current_shop, quantity, base_price, tax_amount, total_price, unit_price)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Execute purchase error: {str(e)}")
            return False, self.language_manager.GetText("SHOP_PURCHASE_ERROR")

    def _execute_sell_shop_purchase(self, player, shop_data, quantity, base_price, tax_amount, total_price, unit_price=None):
        """执行出售商店的购买操作（含无限商店）"""
        try:
            if unit_price is None:
                unit_price = shop_data['unit_price']
            buyer_money = self._get_player_money(player.name)
            if buyer_money < total_price:
                return False, self.language_manager.GetText("SHOP_INSUFFICIENT_FUNDS").format(total_price, buyer_money)
            
            is_infinite = self._is_shop_infinite(shop_data)
            if not is_infinite and shop_data['stock'] < quantity:
                return False, self.language_manager.GetText("SHOP_INSUFFICIENT_STOCK")
            
            # 先尝试发放物品，按“实际发放数量”结算，避免背包满导致部分到账但全额退款的漏洞
            item_data = json.loads(shop_data['item_data'])
            purchase_item = self._shop_item_transaction_payload(item_data, quantity)
            given_qty = self.inventory_manager.give_item_count(player, purchase_item)

            if given_qty <= 0:
                return False, self.language_manager.GetText("SHOP_ITEM_GIVE_FAILED")

            # 按实际发放数量重新计算费用/税
            actual_base_price = int(given_qty * unit_price)
            actual_tax_amount = self._calculate_tax(actual_base_price)
            actual_total_price = actual_base_price + actual_tax_amount

            # 买家扣款
            if not self._change_player_money(player.name, -actual_total_price):
                # 扣款失败：尝试把已发物品收回
                try:
                    rollback_item = self._shop_item_transaction_payload(item_data, given_qty)
                    self.inventory_manager.remove_item(player, rollback_item)
                except Exception:
                    pass
                return False, self.language_manager.GetText("SHOP_PAYMENT_FAILED")

            # 店主收款（系统/无限商店不收款）
            if not is_infinite and not self._change_player_money(shop_data['owner_name'], actual_base_price):
                # 店主收款失败：退还买家并回收物品
                self._change_player_money(player.name, actual_total_price)
                try:
                    rollback_item = self._shop_item_transaction_payload(item_data, given_qty)
                    self.inventory_manager.remove_item(player, rollback_item)
                except Exception:
                    pass
                return False, self.language_manager.GetText("SHOP_OWNER_PAYMENT_FAILED")

            # 更新库存（非无限商店按实际发放数量扣库存）
            update_data = {
                'last_purchase_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            if not is_infinite:
                new_stock = shop_data['stock'] - int(given_qty)
                update_data['stock'] = new_stock
                if new_stock <= 0:
                    update_data['is_active'] = 0

            self.db_manager.update(
                table='button_shops',
                data=update_data,
                where='id = ?',
                params=(shop_data['id'],)
            )

            # 记录交易（按实际数量）
            self._record_transaction(
                shop_data['id'],
                player,
                int(given_qty),
                unit_price,
                actual_total_price,
                actual_tax_amount
            )

            # 通知店主（按实际数量）
            self._notify_shop_owner(shop_data, player.name, int(given_qty), item_data['name'], actual_base_price, "sell")

            # 若实际发放少于输入数量，给出明确提示
            if int(given_qty) < int(quantity):
                msg = self._get_purchase_success_message(int(given_qty), item_data['name'], actual_total_price, actual_tax_amount)
                msg += "\n" + self.language_manager.GetText("SHOP_PARTIAL_PURCHASE_NOTICE").format(given_qty, quantity)
                return True, msg

            return True, self._get_purchase_success_message(int(given_qty), item_data['name'], actual_total_price, actual_tax_amount)
                
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Execute sell shop purchase error: {str(e)}")
            return False, self.language_manager.GetText("SHOP_PURCHASE_ERROR")

    def _execute_buy_shop_purchase(self, player, shop_data, quantity, base_price, tax_amount, total_price, unit_price=None):
        """执行收购商店的购买操作（玩家出售物品给收购商店，含无限商店）"""
        try:
            if unit_price is None:
                unit_price = shop_data['unit_price']
            is_infinite = self._is_shop_infinite(shop_data)
            if not is_infinite and shop_data['stock'] < base_price:
                return False, self.language_manager.GetText("SHOP_INSUFFICIENT_BUDGET")
            
            item_data = json.loads(shop_data['item_data'])
            required_item = self._shop_item_transaction_payload(item_data, quantity)

            if not self.inventory_manager.has_item(player, required_item):
                return False, self.language_manager.GetText("SHOP_PLAYER_NO_ITEMS")
            
            if not self.inventory_manager.remove_item(player, required_item):
                return False, self.language_manager.GetText("SHOP_ITEM_REMOVE_FAILED")
            
            player_income = base_price - tax_amount
            if not self._change_player_money(player.name, player_income):
                self.inventory_manager.give_item(player, required_item)
                return False, self.language_manager.GetText("SHOP_PAYMENT_FAILED")
            
            update_data = {
                'last_purchase_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            if not is_infinite:
                new_budget = shop_data['stock'] - base_price
                collected_items = []
                if shop_data.get('collected_items'):
                    try:
                        collected_items = json.loads(shop_data['collected_items'])
                    except Exception:
                        collected_items = []
                collected_item = {
                    'type': item_data['type'],
                    'name': item_data['name'],
                    'count': quantity,
                    'data': item_data.get('data', 0),
                    'enchants': item_data.get('enchants', {}),
                    'lore': item_data.get('lore', []),
                    'collect_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                if item_data.get('nbt_b64'):
                    collected_item['nbt_b64'] = item_data['nbt_b64']
                collected_items.append(collected_item)
                update_data['stock'] = new_budget
                update_data['collected_items'] = json.dumps(collected_items)
                if new_budget < unit_price:
                    update_data['is_active'] = 0
            
            self.db_manager.update(
                table='button_shops',
                data=update_data,
                where='id = ?',
                params=(shop_data['id'],)
            )
            
            # 记录交易（注意：对收购商店，玩家是卖家）
            self._record_transaction(shop_data['id'], player, quantity, unit_price, base_price, tax_amount, is_buy_shop=True)
            
            # 通知店主（系统商店不通知创建者）
            self._notify_shop_owner(shop_data, player.name, quantity, item_data['name'], base_price, "buy")
            
            return True, self._get_sell_success_message(quantity, item_data['name'], player_income, tax_amount)
                
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Execute buy shop purchase error: {str(e)}")
            return False, self.language_manager.GetText("SHOP_PURCHASE_ERROR")

    # 交易辅助方法
    def _record_transaction(self, shop_id, player, quantity, unit_price, total_price, tax_amount, is_buy_shop=False):
        """记录交易"""
        try:
            transaction_data = {
                'shop_id': shop_id,
                'buyer_xuid': str(player.unique_id),
                'buyer_name': player.name,
                'quantity': quantity,
                'unit_price': unit_price,
                'total_price': total_price,
                'transaction_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            self.db_manager.insert("shop_transactions", transaction_data)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Record transaction error: {str(e)}")

    def _notify_shop_owner(self, shop_data, buyer_name, quantity, item_name, amount, shop_type):
        """通知店主（系统/无限商店不通知创建者，资金与创建者无关）"""
        try:
            if self._is_shop_infinite(shop_data):
                return
            owner_player = self.server.get_player(shop_data['owner_name'])
            if owner_player:
                if shop_type == "sell":
                    message = self.language_manager.GetText("SHOP_SALE_NOTIFICATION").format(
                        buyer_name, quantity, item_name, amount
                    )
                else:
                    message = self.language_manager.GetText("SHOP_BUY_NOTIFICATION").format(
                        buyer_name, quantity, item_name, amount
                    )
                owner_player.send_message(message)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Notify shop owner error: {str(e)}")

    def _get_purchase_success_message(self, quantity, item_name, total_price, tax_amount):
        """获取购买成功消息"""
        if tax_amount > 0:
            tax_percent = int(self._get_tax_rate() * 100)
            return self.language_manager.GetText("SHOP_PURCHASE_SUCCESS_WITH_TAX").format(
                quantity, item_name, total_price, tax_amount
            ) + "\n" + self.language_manager.GetText("SHOP_TAX_INFO").format(tax_percent, tax_amount)
        else:
            return self.language_manager.GetText("SHOP_PURCHASE_SUCCESS").format(
                quantity, item_name, total_price
            )

    def _get_sell_success_message(self, quantity, item_name, income, tax_amount):
        """获取出售成功消息"""
        if tax_amount > 0:
            tax_percent = int(self._get_tax_rate() * 100)
            return self.language_manager.GetText("SHOP_SELL_SUCCESS_WITH_TAX").format(
                quantity, item_name, income, tax_amount
            ) + "\n" + self.language_manager.GetText("SHOP_TAX_INFO").format(tax_percent, tax_amount)
        else:
            return self.language_manager.GetText("SHOP_SELL_SUCCESS").format(
                quantity, item_name, income
            )

    def _rollback_sell_transaction(self, player, shop_data, total_price, base_price, is_infinite=False):
        """回滚出售交易（系统商店未给店主加钱，不得扣店主）"""
        try:
            self._change_player_money(player.name, total_price)
            if not is_infinite:
                self._change_player_money(shop_data['owner_name'], -base_price)
                self.db_manager.update(
                    table='button_shops',
                    data={'stock': shop_data['stock']},
                    where='id = ?',
                    params=(shop_data['id'],)
                )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Rollback transaction error: {str(e)}")

    # 辅助方法
    def _is_button_block(self, block: Block) -> bool:
        """检查是否为按钮方块"""
        # 检查block是否为None
        if block is None:
            return False
            
        # 检查block.type是否为None
        if block.type is None:
            return False
            
        # 检查方块类型是否为按钮
        button_types = [
            "minecraft:wooden_button", "minecraft:stone_button", "minecraft:birch_button",
            "minecraft:spruce_button", "minecraft:jungle_button", "minecraft:acacia_button",
            "minecraft:dark_oak_button", "minecraft:mangrove_button", "minecraft:cherry_button",
            "minecraft:bamboo_button", "minecraft:crimson_button", "minecraft:warped_button",
            "minecraft:polished_blackstone_button"
        ]
        
        # 安全地获取block.type.id
        try:
            if hasattr(block.type, 'id'):
                return block.type.id in button_types
            else:
                # 如果block.type没有id属性，尝试转换为字符串进行比较
                block_type_str = str(block.type)
                return block_type_str in button_types
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Error checking button block: {str(e)}")
            return False

    def _get_shop_at_position(self, x: int, y: int, z: int, dimension: str):
        """获取指定位置的商店（直接查询，用于API接口）"""
        try:
            return self.db_manager.query_one(
                "SELECT * FROM button_shops WHERE x = ? AND y = ? AND z = ? AND dimension = ? AND is_active = 1",
                (x, y, z, dimension)
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get shop at position error: {str(e)}")
            return None

    def _get_shop_at_position_optimized(self, x: int, y: int, z: int, dimension: str):
        """获取指定位置的商店（优化版本，先查区块索引）"""
        try:
            # 1. 计算区块坐标
            chunk_x, chunk_z = self._get_chunk_coords(x, z)
            
            # 2. 检查该区块是否有商店
            chunk_has_shops = self.db_manager.query_one(
                "SELECT COUNT(*) as count FROM chunk_index WHERE chunk_x = ? AND chunk_z = ? AND dimension = ? AND shop_count > 0",
                (chunk_x, chunk_z, dimension)
            )
            
            # 3. 如果区块没有商店，直接返回None
            if not chunk_has_shops or chunk_has_shops['count'] == 0:
                return None
            
            # 4. 如果区块有商店，再精确查询该位置的商店
            return self.db_manager.query_one(
                "SELECT * FROM button_shops WHERE x = ? AND y = ? AND z = ? AND dimension = ? AND is_active = 1",
                (x, y, z, dimension)
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get shop at position optimized error: {str(e)}")
            return None

    def _get_shop_by_id(self, shop_id: int):
        """根据ID获取商店"""
        try:
            return self.db_manager.query_one(
                "SELECT * FROM button_shops WHERE id = ?",
                (shop_id,)
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get shop by id error: {str(e)}")
            return None

    def _get_chunk_coords(self, x: int, z: int) -> tuple:
        """获取区块坐标"""
        return x // self.CHUNK_SIZE, z // self.CHUNK_SIZE

    def _update_chunk_index(self, chunk_x: int, chunk_z: int, dimension: str, delta: int):
        """更新区块索引"""
        try:
            # 先尝试获取现有记录
            existing = self.db_manager.query_one(
                "SELECT shop_count FROM chunk_index WHERE chunk_x = ? AND chunk_z = ? AND dimension = ?",
                (chunk_x, chunk_z, dimension)
            )
            
            if existing:
                # 更新现有记录
                new_count = max(0, existing['shop_count'] + delta)
                self.db_manager.update(
                    table='chunk_index',
                    data={'shop_count': new_count},
                    where='chunk_x = ? AND chunk_z = ? AND dimension = ?',
                    params=(chunk_x, chunk_z, dimension)
                )
            else:
                # 创建新记录
                self.db_manager.insert("chunk_index", {
                    'chunk_x': chunk_x,
                    'chunk_z': chunk_z,
                    'dimension': dimension,
                    'shop_count': max(0, delta)
                })
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Update chunk index error: {str(e)}")

    def _generate_shop_uuid(self) -> str:
        """生成商店UUID"""
        import uuid
        return str(uuid.uuid4())

    def _calculate_tax(self, amount: int) -> int:
        """计算交易税（整数）"""
        try:
            tax_enabled = self.setting_manager.GetSetting("trade_tax_enabled")
            if tax_enabled and tax_enabled.lower() == "true":
                tax_rate = float(self.setting_manager.GetSetting("trade_tax_rate") or "0.05")
                return int(amount * tax_rate)
            return 0
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Calculate tax error: {str(e)}")
            return 0

    def _get_tax_rate(self) -> float:
        """获取税率"""
        try:
            return float(self.setting_manager.GetSetting("trade_tax_rate") or "0.05")
        except Exception:
            return 0.05

    def _handle_shop_manage_command(self, sender: CommandSender, args: list[str]) -> bool:
        """处理商店管理命令"""
        if not sender.is_op:
            sender.send_message(self.language_manager.GetText("NO_PERMISSION"))
            return True
        
        if not args:
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_USAGE"))
            return True
        
        command = args[0].lower()
        
        if command == "list":
            # 列出所有商店
            shops = self.db_manager.query_all("SELECT * FROM button_shops WHERE is_active = 1")
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_ACTIVE_COUNT").format(len(shops)))
            
        elif command == "clear":
            # 清除所有商店（危险操作）
            self.db_manager.execute("DELETE FROM button_shops")
            self.db_manager.execute("DELETE FROM shop_transactions") 
            self.db_manager.execute("DELETE FROM chunk_index")
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_CLEAR_SUCCESS"))
            
        elif command == "reload":
            # 重新加载配置
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_RELOAD_SUCCESS"))
            
        elif command == "prices":
            # 查看官方定价概览
            self._handle_prices_command(sender)
            
        elif command == "pricereload":
            # 重新加载官方定价配置
            self.price_manager.reload_config()
            self.price_manager.load_price_adjustments_from_db(self.db_manager)
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_PRICERELOAD_SUCCESS"))
            
        elif command == "pricereset":
            # 重置所有动态价格调整
            self.price_manager.reset_all_adjustments(self.db_manager)
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_PRICERESET_SUCCESS"))
            
        else:
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_USAGE"))
            
        return True

    def _handle_prices_command(self, sender: CommandSender):
        """处理 /shopmanage prices 命令"""
        priced_items = self.price_manager.get_all_priced_items()
        if not priced_items:
            sender.send_message(self.language_manager.GetText("SHOP_MANAGE_PRICES_NO_ITEMS"))
            return
        
        dynamic_enabled = self.price_manager.dynamic_pricing_config.get('enabled', False)
        daily_enabled = self.price_manager.daily_fluctuation_config.get('enabled', False)
        
        content = self.language_manager.GetText("SHOP_MANAGE_PRICES_CONTENT").format(
            len(priced_items),
            "§a启用" if dynamic_enabled else "§c禁用",
            "§a启用" if daily_enabled else "§c禁用"
        )
        sender.send_message(content)
        
        # 显示每个物品的定价信息
        for item_type, prices in priced_items.items():
            display_name = self.price_manager.get_item_display_name(item_type)
            sell_price = prices.get('sell', 'N/A')
            buy_price = prices.get('buy', 'N/A')
            adj = self.price_manager.get_price_adjustment(item_type)
            
            line = f"§f{display_name}: §a出售{sell_price} §b收购{buy_price}"
            if adj['daily_adjust_percent'] != 0:
                sign = "+" if adj['daily_adjust_percent'] > 0 else ""
                line += f" §7(波动{sign}{adj['daily_adjust_percent']:.1f}%)"
            sender.send_message(line)

    def _show_all_shops_panel(self, player):
        """显示全部商店面板（OP 管理用）"""
        try:
            if not getattr(player, 'is_op', False):
                player.send_message(self.language_manager.GetText("NO_PERMISSION"))
                return
            all_shops = self.db_manager.query_all(
                "SELECT * FROM button_shops WHERE is_active = 1 ORDER BY create_time DESC"
            )
            if not all_shops:
                no_shops_panel = ActionForm(
                    title=self.language_manager.GetText("SHOP_ALL_SHOPS_TITLE"),
                    content=self.language_manager.GetText("SHOP_NO_ACTIVE_SHOPS")
                )
                no_shops_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_main_panel(sender)
                )
                player.send_form(no_shops_panel)
                return
            panel = ActionForm(
                title=self.language_manager.GetText("SHOP_MANAGE_ALL_SHOPS_BUTTON"),
                content=self.language_manager.GetText("SHOP_ALL_SHOPS_CONTENT").format(len(all_shops))
            )
            for shop in all_shops[:50]:
                item_data = json.loads(shop['item_data'])
                is_infinite = self._is_shop_infinite(shop)
                stock_text = self.language_manager.GetText("SHOP_STOCK_INFINITE") if is_infinite else shop['stock']
                display_price = self._get_shop_display_price(shop)
                button_text = f"{self._get_shop_type_short_tag(shop)} {item_data['name']} - {self._get_shop_owner_display(shop)} - {self.language_manager.GetText('SHOP_STOCK_LABEL') if shop.get('shop_type', 'sell') == 'sell' else self.language_manager.GetText('SHOP_BUDGET_LABEL')}:{stock_text} - {self.language_manager.GetText('SHOP_UNIT_PRICE_LABEL')}:{display_price}"
                panel.add_button(
                    button_text,
                    on_click=lambda sender, s=shop: self._show_shop_manage_panel(sender, s, from_all_shops=True)
                )
            panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_main_panel(sender)
            )
            player.send_form(panel)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show all shops panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_ALL_SHOPS_PANEL_ERROR"))

    def _show_my_shops_panel(self, player):
        """显示我的商店面板"""
        try:
            my_shops = self.db_manager.query_all(
                "SELECT * FROM button_shops WHERE owner_xuid = ? AND is_active = 1 ORDER BY create_time DESC",
                (str(player.unique_id),)
            )
            
            if not my_shops:
                no_shops_panel = ActionForm(
                    title=self.language_manager.GetText("SHOP_MY_SHOPS_TITLE"),
                    content=self.language_manager.GetText("SHOP_NO_MY_SHOPS")
                )
                no_shops_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_main_panel(sender)
                )
                player.send_form(no_shops_panel)
                return
            
            # 显示商店列表
            my_shops_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_MY_SHOPS_TITLE"),
                content=self.language_manager.GetText("SHOP_MY_SHOPS_CONTENT").format(len(my_shops))
            )
            
            for shop in my_shops:
                item_data = json.loads(shop['item_data'])
                stock_text = self.language_manager.GetText("SHOP_STOCK_INFINITE") if self._is_shop_infinite(shop) else shop['stock']
                display_price = self._get_shop_display_price(shop)
                button_text = f"{self._get_shop_type_short_tag(shop)} {item_data['name']} - {self.language_manager.GetText('SHOP_STOCK_LABEL')}:{stock_text} - {self.language_manager.GetText('SHOP_UNIT_PRICE_LABEL')}:{display_price}"
                if item_data.get('enchants'):
                    button_text += f" §b[{self.language_manager.GetText('SHOP_ENCHANT_TAG')}]"
                if item_data.get('lore'):
                    button_text += f" §d[{self.language_manager.GetText('SHOP_LORE_TAG')}]"
                my_shops_panel.add_button(
                    button_text,
                    on_click=lambda sender, s=shop: self._show_shop_manage_panel(sender, s)
                )
            
            my_shops_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_main_panel(sender)
            )
            
            player.send_form(my_shops_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show my shops error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_ALL_SHOPS_PANEL_ERROR"))

    def _show_nearby_shops_panel(self, player):
        """显示附近商店面板"""
        try:
            player_loc = player.location
            chunk_x, chunk_z = self._get_chunk_coords(int(player_loc.x), int(player_loc.z))
            
            # 搜索附近9个区块的商店
            nearby_shops = []
            for dx in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    search_chunk_x = chunk_x + dx
                    search_chunk_z = chunk_z + dz
                    
                    chunk_shops = self.db_manager.query_all(
                        "SELECT * FROM button_shops WHERE chunk_x = ? AND chunk_z = ? AND dimension = ? AND is_active = 1",
                        (search_chunk_x, search_chunk_z, player_loc.dimension.name)
                    )
                    nearby_shops.extend(chunk_shops)
            
            if not nearby_shops:
                no_shops_panel = ActionForm(
                    title=self.language_manager.GetText("SHOP_NEARBY_SHOPS_TITLE"),
                    content=self.language_manager.GetText("SHOP_NO_NEARBY_SHOPS")
                )
                no_shops_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_main_panel(sender)
                )
                player.send_form(no_shops_panel)
                return
            
            # 显示附近商店
            nearby_panel = ActionForm(
                title=self.language_manager.GetText("SHOP_NEARBY_SHOPS_TITLE"),
                content=self.language_manager.GetText("SHOP_NEARBY_SHOPS_CONTENT").format(len(nearby_shops))
            )
            
            for shop in nearby_shops[:20]:  # 最多显示20个
                item_data = json.loads(shop['item_data'])
                distance = math.sqrt(
                    (shop['x'] - player_loc.x) ** 2 + 
                    (shop['z'] - player_loc.z) ** 2
                )
                button_text = f"{self._get_shop_type_short_tag(shop)} {item_data['name']} - {self._get_shop_owner_display(shop)} - {distance:.1f}{self.language_manager.GetText('SHOP_BLOCKS_UNIT')}"
                
                # 添加附魔和Lore标识
                if item_data.get('enchants'):
                    button_text += f" §b[{self.language_manager.GetText('SHOP_ENCHANT_TAG')}]"
                if item_data.get('lore'):
                    button_text += f" §d[{self.language_manager.GetText('SHOP_LORE_TAG')}]"
                
                nearby_panel.add_button(
                    button_text,
                    on_click=lambda sender, s=shop: self._show_shop_detail_panel(sender, s)
                )
            
            nearby_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_main_panel(sender)
            )
            
            player.send_form(nearby_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show nearby shops error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_NEARBY_SHOPS_PANEL_ERROR"))

    def _show_shop_manage_panel(self, player, shop_data, from_all_shops=False):
        """显示商店管理面板（from_all_shops 为 True 时返回至「管理全部商店」）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            stock_text = self.language_manager.GetText("SHOP_STOCK_INFINITE") if is_infinite else shop_data['stock']
            
            price_label = self.language_manager.GetText("SHOP_PRICE_SELL_LABEL") if shop_type == "sell" else self.language_manager.GetText("SHOP_PRICE_BUY_LABEL")
            is_op_player = getattr(player, 'is_op', False)
            op_hint = self.language_manager.GetText("SHOP_OP_MANAGE_HINT") if is_op_player else ""
            # 无 § 的短标题置顶，避免正文里只注意到物品与单价
            manage_info = f"""{op_hint}{self.language_manager.GetText('SHOP_MANAGE_INFO_LABEL')}
————————————
{self._get_shop_type_plain_headline(shop_data)}
————————————
{self._get_shop_type_manage_line(shop_data)}

{self.language_manager.GetText('SHOP_DETAIL_ITEM')}: {item_data['name']}
{self.language_manager.GetText('SHOP_STOCK_LABEL') if shop_type == 'sell' else self.language_manager.GetText('SHOP_BUDGET_BALANCE_LABEL')}: {stock_text}
{price_label}: {shop_data['unit_price']}
{self.language_manager.GetText('SHOP_MANAGE_POSITION')}: ({shop_data['x']}, {shop_data['y']}, {shop_data['z']})
{self.language_manager.GetText('SHOP_MANAGE_CREATE_TIME')}: {shop_data['create_time']}"""
            
            # 添加附魔信息
            if item_data.get('enchants'):
                manage_info += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_ENCHANTS')}:"
                for enchant_id, level in item_data['enchants'].items():
                    manage_info += f"\n  {enchant_id} [{self.language_manager.GetText('SHOP_MANAGE_LEVEL')} {level}]"
            
            # 添加Lore信息
            if item_data.get('lore'):
                manage_info += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_LORE')}:"
                for lore_line in item_data['lore']:
                    manage_info += f"\n  {lore_line}"
            
            # 收购商店显示收集的物品信息
            if shop_type == "buy":
                collected_items = []
                if shop_data.get('collected_items'):
                    try:
                        collected_items = json.loads(shop_data['collected_items'])
                    except:
                        collected_items = []
                
                total_collected = sum(item['count'] for item in collected_items)
                manage_info += f"\n\n{self.language_manager.GetText('SHOP_COLLECTED_ITEMS_TOTAL')}: {total_collected}"
            
            manage_title = f"{self.language_manager.GetText('SHOP_MANAGE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            manage_panel = ActionForm(
                title=manage_title,
                content=manage_info
            )
            
            # 根据商店类型显示不同的按钮（无限商店不显示补充库存/收取物品）
            if not is_infinite:
                if shop_type == "sell":
                    if shop_data['stock'] < shop_data['quantity']:
                        manage_panel.add_button(
                            self.language_manager.GetText("SHOP_RESTOCK_BUTTON"),
                            on_click=lambda sender: self._show_restock_panel(sender, shop_data, from_all_shops)
                        )
                else:
                    collected_items = []
                    if shop_data.get('collected_items'):
                        try:
                            collected_items = json.loads(shop_data['collected_items'])
                        except Exception:
                            collected_items = []
                    if collected_items:
                        manage_panel.add_button(
                            self.language_manager.GetText("SHOP_COLLECT_ITEMS_BUTTON"),
                            on_click=lambda sender: self._show_collect_items_panel(sender, shop_data, from_all_shops)
                        )
            
            # OP 专属：将商店转换为无限商店（系统商店）
            if getattr(player, 'is_op', False) and not is_infinite:
                manage_panel.add_button(
                    self.language_manager.GetText("SHOP_CONVERT_INFINITE_BUTTON"),
                    on_click=lambda sender: self._convert_shop_to_infinite(sender, shop_data, from_all_shops)
                )
            
            # 删除商店按钮
            manage_panel.add_button(
                self.language_manager.GetText("SHOP_DELETE_SHOP_BUTTON"),
                on_click=lambda sender: self._show_delete_shop_panel(sender, shop_data, from_all_shops)
            )
            
            manage_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_all_shops_panel(sender) if from_all_shops else self._show_my_shops_panel(sender)
            )
            
            player.send_form(manage_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show shop manage panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_MANAGE_PANEL_ERROR"))

    def _convert_shop_to_infinite(self, player, shop_data, from_all_shops=False):
        """将商店转换为无限商店（系统商店），仅 OP 可用"""
        try:
            if not getattr(player, 'is_op', False):
                player.send_message(self.language_manager.GetText("NO_PERMISSION"))
                return
            if self._is_shop_infinite(shop_data):
                result_form = ActionForm(
                    title=self.language_manager.GetText("SHOP_CONVERT_INFINITE_TITLE"),
                    content=self.language_manager.GetText("SHOP_ALREADY_INFINITE")
                )
                result_form.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda s: self._show_shop_manage_panel(s, shop_data, from_all_shops)
                )
                player.send_form(result_form)
                return
            self.db_manager.update(
                table='button_shops',
                data={'is_infinite': 1, 'stock': self.UNLIMITED_STOCK, 'quantity': self.UNLIMITED_STOCK},
                where='id = ?',
                params=(shop_data['id'],)
            )
            updated = self._get_shop_by_id(shop_data['id'])
            if updated:
                shop_data = updated
            result_form = ActionForm(
                title=self.language_manager.GetText("SHOP_CONVERT_INFINITE_TITLE"),
                content=self.language_manager.GetText("SHOP_CONVERT_INFINITE_SUCCESS")
            )
            result_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda s: self._show_shop_manage_panel(s, shop_data, from_all_shops)
            )
            player.send_form(result_form)
            self._safe_log('info', f"[ARCButtonShop] Shop {shop_data['id']} converted to infinite by {player.name}")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Convert to infinite error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_CONVERT_INFINITE_ERROR"))

    def _show_restock_panel(self, player, shop_data, from_all_shops=False):
        """显示补充库存面板（from_all_shops 用于返回至管理面板时保持来源）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            restock_title = f"{self.language_manager.GetText('SHOP_RESTOCK_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            restock_info = f"{self._get_shop_type_plain_headline(shop_data)}\n\n{self.language_manager.GetText('SHOP_RESTOCK_FOR_ITEM').format(item_data['name'])}\n{self.language_manager.GetText('SHOP_CURRENT_STOCK')}: {shop_data['stock']}"
            
            # 添加附魔信息
            if item_data.get('enchants'):
                restock_info += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_ENCHANTS')}:"
                for enchant_id, level in item_data['enchants'].items():
                    restock_info += f"\n  {enchant_id} [{self.language_manager.GetText('SHOP_MANAGE_LEVEL')} {level}]"
            
            # 添加Lore信息
            if item_data.get('lore'):
                restock_info += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_LORE')}:"
                for lore_line in item_data['lore']:
                    restock_info += f"\n  {lore_line}"
            
            restock_label = Label(text=restock_info)
            
            quantity_input = TextInput(
                label=self.language_manager.GetText("SHOP_RESTOCK_QUANTITY_LABEL"),
                placeholder=self.language_manager.GetText("SHOP_RESTOCK_QUANTITY_PLACEHOLDER"),
                default_value=""
            )
            
            def process_restock(sender, json_str: str):
                try:
                    data = json.loads(json_str)
                    quantity_str = data[1]
                    
                    try:
                        quantity = int(quantity_str)
                        if quantity <= 0:
                            raise ValueError("Quantity must be positive")
                    except ValueError:
                        error_form = ActionForm(
                            title=restock_title,
                            content=self.language_manager.GetText("SHOP_INVALID_QUANTITY")
                        )
                        error_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_restock_panel(s, shop_data, from_all_shops)
                        )
                        sender.send_form(error_form)
                        return
                    
                    # 检查玩家是否有足够的物品
                    required_item = self._shop_item_transaction_payload(item_data, quantity)

                    if self.inventory_manager.has_item(sender, required_item) and self.inventory_manager.remove_item(sender, required_item):
                        # 更新库存
                        new_stock = shop_data['stock'] + quantity
                        self.db_manager.update(
                            table='button_shops',
                            data={'stock': new_stock, 'is_active': 1},
                            where='id = ?',
                            params=(shop_data['id'],)
                        )
                        
                        success_form = ActionForm(
                            title=restock_title,
                            content=self.language_manager.GetText("SHOP_RESTOCK_SUCCESS").format(quantity, item_data['name'])
                        )
                        success_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_shop_manage_panel(s, shop_data, from_all_shops)
                            if from_all_shops else self._show_my_shops_panel(s)
                        )
                        sender.send_form(success_form)
                    else:
                        error_form = ActionForm(
                            title=restock_title,
                            content=self.language_manager.GetText("SHOP_NOT_ENOUGH_ITEMS")
                        )
                        error_form.add_button(
                            self.language_manager.GetText("SHOP_BACK_BUTTON"),
                            on_click=lambda s: self._show_restock_panel(s, shop_data, from_all_shops)
                        )
                        sender.send_form(error_form)
                
                except Exception as e:
                    self._safe_log('error', f"[ARCButtonShop] Process restock error: {str(e)}")
                    error_form = ActionForm(
                        title=restock_title,
                        content=self.language_manager.GetText("SHOP_RESTOCK_ERROR")
                    )
                    error_form.add_button(
                        self.language_manager.GetText("SHOP_BACK_BUTTON"),
                        on_click=lambda s: self._show_shop_manage_panel(s, shop_data, from_all_shops)
                    )
                    sender.send_form(error_form)
            
            restock_panel = ModalForm(
                title=restock_title,
                controls=[restock_label, quantity_input],
                on_submit=process_restock
            )
            
            player.send_form(restock_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show restock panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_RESTOCK_PANEL_ERROR"))

    def _show_delete_shop_panel(self, player, shop_data, from_all_shops=False):
        """显示删除商店确认面板（from_all_shops 为 True 时删除后返回「管理全部商店」）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            stock_display = self.language_manager.GetText('SHOP_STOCK_INFINITE') if is_infinite else shop_data['stock']
            stock_line = (
                f"{self.language_manager.GetText('SHOP_REMAINING_STOCK')}: {stock_display}"
                if shop_type == 'sell'
                else f"{self.language_manager.GetText('SHOP_REMAINING_BUDGET')}: {stock_display}"
            )
            delete_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            confirm_content = f"""{self._get_shop_type_plain_headline(shop_data)}

{self.language_manager.GetText('SHOP_CONFIRM_DELETE')}

{self.language_manager.GetText('SHOP_DETAIL_ITEM')}: {item_data['name']}
{stock_line}"""
            
            # 添加附魔信息
            if item_data.get('enchants'):
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_ENCHANTS')}:"
                for enchant_id, level in item_data['enchants'].items():
                    confirm_content += f"\n  {enchant_id} [{self.language_manager.GetText('SHOP_MANAGE_LEVEL')} {level}]"
            
            # 添加Lore信息
            if item_data.get('lore'):
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_LORE')}:"
                for lore_line in item_data['lore']:
                    confirm_content += f"\n  {lore_line}"
            
            if is_infinite:
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_INFINITE_NOTICE')}"
            elif shop_type == 'sell':
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_SELL_NOTICE')}"
            else:
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_BUY_NOTICE')}"
            
            confirm_panel = ActionForm(
                title=delete_title,
                content=confirm_content
            )
            
            confirm_panel.add_button(
                self.language_manager.GetText("SHOP_CONFIRM_DELETE_BUTTON"),
                on_click=lambda sender: self._execute_delete_shop(sender, shop_data, from_all_shops)
            )
            
            confirm_panel.add_button(
                self.language_manager.GetText("SHOP_CANCEL_BUTTON"),
                on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
            )
            
            player.send_form(confirm_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show delete shop panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_DELETE_PANEL_ERROR"))

    def _show_break_delete_confirm_panel(self, player, shop_data):
        """破坏按钮时直接显示删除确认面板（含商店基本信息、确认/取消）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            stock_display = self.language_manager.GetText('SHOP_STOCK_INFINITE') if is_infinite else shop_data['stock']
            stock_line = (
                f"{self.language_manager.GetText('SHOP_REMAINING_STOCK')}: {stock_display}"
                if shop_type == 'sell'
                else f"{self.language_manager.GetText('SHOP_REMAINING_BUDGET')}: {stock_display}"
            )
            confirm_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            confirm_content = f"""{self._get_shop_type_plain_headline(shop_data)}

{self.language_manager.GetText('SHOP_CONFIRM_DELETE')}

{self.language_manager.GetText('SHOP_DETAIL_ITEM')}: {item_data['name']}
{stock_line}
{self.language_manager.GetText('SHOP_UNIT_PRICE_LABEL')}: {shop_data['unit_price']}"""

            # 添加附魔信息
            if item_data.get('enchants'):
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_ENCHANTS')}:"
                for enchant_id, level in item_data['enchants'].items():
                    confirm_content += f"\n  {enchant_id} [{self.language_manager.GetText('SHOP_MANAGE_LEVEL')} {level}]"

            # 添加Lore信息
            if item_data.get('lore'):
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_MANAGE_LORE')}:"
                for lore_line in item_data['lore']:
                    confirm_content += f"\n  {lore_line}"

            if is_infinite:
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_INFINITE_NOTICE')}"
            elif shop_type == 'sell':
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_SELL_NOTICE')}"
            else:
                confirm_content += f"\n\n{self.language_manager.GetText('SHOP_DELETE_BUY_NOTICE')}"

            confirm_panel = ActionForm(
                title=confirm_title,
                content=confirm_content
            )

            confirm_panel.add_button(
                self.language_manager.GetText("SHOP_CONFIRM_DELETE_BUTTON"),
                on_click=lambda sender: self._execute_break_delete(sender, shop_data)
            )

            confirm_panel.add_button(
                self.language_manager.GetText("SHOP_CANCEL_BUTTON"),
                on_click=lambda sender: None
            )

            player.send_form(confirm_panel)

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show break delete confirm panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_DELETE_PANEL_ERROR"))

    def _execute_break_delete(self, player, shop_data):
        """执行破坏按钮触发的删除操作，删除后仅显示结果不返回任何列表"""
        try:
            self._handle_shop_removal_by_owner(player, shop_data)

            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            delete_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"

            if is_infinite:
                result_content = self.language_manager.GetText("SHOP_SYSTEM_DELETE_SUCCESS")
            elif shop_type == 'sell':
                result_content = self.language_manager.GetText("SHOP_DELETE_SELL_RETURN").format(shop_data['stock'], item_data['name'])
            else:
                result_content = self.language_manager.GetText("SHOP_DELETE_BUY_RETURN").format(shop_data['stock'])

            result_form = ActionForm(
                title=delete_title,
                content=result_content
            )
            result_form.add_button(
                self.language_manager.GetText("SHOP_CLOSE_BUTTON"),
                on_click=lambda sender: None
            )
            player.send_form(result_form)

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Execute break delete error: {str(e)}")
            delete_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            error_form = ActionForm(
                title=delete_title,
                content=self.language_manager.GetText("SHOP_DELETE_ERROR")
            )
            error_form.add_button(
                self.language_manager.GetText("SHOP_CLOSE_BUTTON"),
                on_click=lambda sender: None
            )
            player.send_form(error_form)

    def _handle_shop_removal_by_owner(self, player, shop_data):
        """处理店主破坏商店按钮（删除商店）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            
            if not is_infinite:
                if shop_type == "sell":
                    if shop_data['stock'] > 0:
                        return_item = self._shop_item_transaction_payload(item_data, shop_data['stock'])
                        self.inventory_manager.give_item(player, return_item)
                        player.send_message(self.language_manager.GetText("SHOP_REMOVED_BY_OWNER_SELL").format(
                            shop_data['stock'], item_data['name']
                        ))
                else:
                    if shop_data['stock'] > 0:
                        self._change_player_money(player.name, shop_data['stock'])
                        player.send_message(self.language_manager.GetText("SHOP_REMOVED_BY_OWNER_BUY").format(
                            shop_data['stock']
                        ))
                    collected_items = []
                    if shop_data.get('collected_items'):
                        try:
                            collected_items = json.loads(shop_data['collected_items'])
                        except Exception:
                            collected_items = []
                    if collected_items:
                        total_items = sum(item['count'] for item in collected_items)
                        for item in collected_items:
                            self.inventory_manager.give_item(player, item)
                        player.send_message(self.language_manager.GetText("SHOP_BREAK_DELETE_SUCCESS").format(len(collected_items), total_items))
            else:
                player.send_message(self.language_manager.GetText("SHOP_SYSTEM_DELETED"))
            
            # 删除商店记录
            self.db_manager.delete(
                table='button_shops',
                where='id = ?',
                params=(shop_data['id'],)
            )
            
            # 更新区块索引
            self._update_chunk_index(shop_data['chunk_x'], shop_data['chunk_z'], shop_data['dimension'], -1)
            
            self._safe_log('info', f"[ARCButtonShop] Shop removed by owner {player.name} at ({shop_data['x']}, {shop_data['y']}, {shop_data['z']})")
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Handle shop removal by owner error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_REMOVAL_ERROR"))

    def _show_collect_items_panel(self, player, shop_data, from_all_shops=False):
        """显示收取物品面板（from_all_shops 用于返回至管理面板时保持来源）"""
        try:
            collect_title = f"{self.language_manager.GetText('SHOP_COLLECT_ITEMS_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            collected_items = []
            if shop_data.get('collected_items'):
                try:
                    collected_items = json.loads(shop_data['collected_items'])
                except Exception:
                    collected_items = []
            
            if not collected_items:
                no_items_panel = ActionForm(
                    title=collect_title,
                    content=f"{self._get_shop_type_plain_headline(shop_data)}\n\n{self.language_manager.GetText('SHOP_NO_COLLECTED_ITEMS')}"
                )
                no_items_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
                )
                player.send_form(no_items_panel)
                return
            
            collect_panel = ActionForm(
                title=collect_title,
                content=f"{self._get_shop_type_plain_headline(shop_data)}\n\n{self.language_manager.GetText('SHOP_COLLECTED_ITEMS_COUNT').format(len(collected_items))}"
            )
            
            for i, item in enumerate(collected_items):
                button_text = f"{item['name']} x{item['count']} - {item['collect_time']}"
                if item.get('enchants'):
                    button_text += f" §b[{self.language_manager.GetText('SHOP_ENCHANT_TAG')}]"
                if item.get('lore'):
                    button_text += f" §d[{self.language_manager.GetText('SHOP_LORE_TAG')}]"
                collect_panel.add_button(
                    button_text,
                    on_click=lambda sender, item_data=item, item_index=i: self._collect_single_item(sender, shop_data, item_data, item_index, from_all_shops)
                )
            
            collect_panel.add_button(
                self.language_manager.GetText("SHOP_COLLECT_ALL_BUTTON"),
                on_click=lambda sender: self._collect_all_items(sender, shop_data, from_all_shops)
            )
            
            collect_panel.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
            )
            
            player.send_form(collect_panel)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Show collect items panel error: {str(e)}")
            player.send_message(self.language_manager.GetText("SHOP_COLLECT_PANEL_ERROR"))

    def _collect_single_item(self, player, shop_data, item_data, item_index, from_all_shops=False):
        """收取单个物品"""
        try:
            collect_title = f"{self.language_manager.GetText('SHOP_COLLECT_ITEMS_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            if self.inventory_manager.give_item(player, item_data):
                collected_items = []
                if shop_data.get('collected_items'):
                    try:
                        collected_items = json.loads(shop_data['collected_items'])
                    except Exception:
                        collected_items = []
                if item_index < len(collected_items):
                    collected_items.pop(item_index)
                self.db_manager.update(
                    table='button_shops',
                    data={'collected_items': json.dumps(collected_items)},
                    where='id = ?',
                    params=(shop_data['id'],)
                )
                success_form = ActionForm(
                    title=collect_title,
                    content=self.language_manager.GetText("SHOP_COLLECT_SINGLE_SUCCESS").format(item_data['count'], item_data['name'])
                )
                success_form.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_collect_items_panel(sender, shop_data, from_all_shops)
                )
                player.send_form(success_form)
            else:
                error_form = ActionForm(
                    title=collect_title,
                    content=self.language_manager.GetText("SHOP_INVENTORY_FULL_COLLECT")
                )
                error_form.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_collect_items_panel(sender, shop_data, from_all_shops)
                )
                player.send_form(error_form)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Collect single item error: {str(e)}")
            collect_title = f"{self.language_manager.GetText('SHOP_COLLECT_ITEMS_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            error_form = ActionForm(
                title=collect_title,
                content=self.language_manager.GetText("SHOP_COLLECT_ITEM_ERROR")
            )
            error_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_collect_items_panel(sender, shop_data, from_all_shops)
            )
            player.send_form(error_form)

    def _collect_all_items(self, player, shop_data, from_all_shops=False):
        """一键收取所有物品"""
        try:
            collect_title = f"{self.language_manager.GetText('SHOP_COLLECT_ITEMS_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            collected_items = []
            if shop_data.get('collected_items'):
                try:
                    collected_items = json.loads(shop_data['collected_items'])
                except Exception:
                    collected_items = []
            if not collected_items:
                no_items_panel = ActionForm(
                    title=collect_title,
                    content=f"{self._get_shop_type_plain_headline(shop_data)}\n\n{self.language_manager.GetText('SHOP_NO_COLLECTED_ITEMS')}"
                )
                no_items_panel.add_button(
                    self.language_manager.GetText("SHOP_BACK_BUTTON"),
                    on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
                )
                player.send_form(no_items_panel)
                return
            success_count = 0
            failed_items = []
            for item in collected_items:
                if self.inventory_manager.give_item(player, item):
                    success_count += 1
                else:
                    failed_items.append(item)
            if success_count > 0:
                self.db_manager.update(
                    table='button_shops',
                    data={'collected_items': json.dumps(failed_items)},
                    where='id = ?',
                    params=(shop_data['id'],)
                )
            if success_count == len(collected_items):
                result_content = self.language_manager.GetText("SHOP_COLLECT_ALL_SUCCESS").format(success_count)
            elif success_count > 0:
                result_content = self.language_manager.GetText("SHOP_COLLECT_PARTIAL_SUCCESS").format(success_count, len(failed_items))
            else:
                result_content = self.language_manager.GetText("SHOP_INVENTORY_FULL_COLLECT_ALL")
            result_form = ActionForm(
                title=collect_title,
                content=result_content
            )
            result_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
            )
            player.send_form(result_form)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Collect all items error: {str(e)}")
            collect_title = f"{self.language_manager.GetText('SHOP_COLLECT_ITEMS_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            error_form = ActionForm(
                title=collect_title,
                content=self.language_manager.GetText("SHOP_COLLECT_ITEM_ERROR")
            )
            error_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=lambda sender: self._show_shop_manage_panel(sender, shop_data, from_all_shops)
            )
            player.send_form(error_form)

    def _execute_delete_shop(self, player, shop_data, from_all_shops=False):
        """执行删除商店操作（from_all_shops 为 True 时删除后返回「管理全部商店」；返还物品/资金给店主）"""
        try:
            item_data = json.loads(shop_data['item_data'])
            shop_type = shop_data.get('shop_type', 'sell')
            is_infinite = self._is_shop_infinite(shop_data)
            delete_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            owner_name = shop_data['owner_name']
            owner_player = self.server.get_player(owner_name)  # 店主（在线才可返还物品）
            
            if not is_infinite:
                if shop_type == "sell":
                    if shop_data['stock'] > 0 and owner_player:
                        return_item = self._shop_item_transaction_payload(item_data, shop_data['stock'])
                        self.inventory_manager.give_item(owner_player, return_item)
                else:
                    if shop_data['stock'] > 0:
                        self._change_player_money(owner_name, shop_data['stock'])
                    collected_items = []
                    if shop_data.get('collected_items'):
                        try:
                            collected_items = json.loads(shop_data['collected_items'])
                        except Exception:
                            collected_items = []
                    for item in collected_items:
                        if owner_player:
                            self.inventory_manager.give_item(owner_player, item)
            
            self.db_manager.delete(
                table='button_shops',
                where='id = ?',
                params=(shop_data['id'],)
            )
            self._update_chunk_index(shop_data['chunk_x'], shop_data['chunk_z'], shop_data['dimension'], -1)
            
            if is_infinite:
                result_content = self.language_manager.GetText("SHOP_SYSTEM_DELETE_SUCCESS")
            elif shop_type == "sell":
                result_content = self.language_manager.GetText("SHOP_DELETE_SELL_RETURN").format(shop_data['stock'], item_data['name'])
            else:
                result_content = self.language_manager.GetText("SHOP_DELETE_BUY_RETURN").format(shop_data['stock'])
            
            go_back = lambda s: self._show_all_shops_panel(s) if from_all_shops else self._show_my_shops_panel(s)
            result_form = ActionForm(
                title=delete_title,
                content=result_content
            )
            result_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=go_back
            )
            player.send_form(result_form)
            self._safe_log('info', f"[ARCButtonShop] Shop deleted by {player.name} at ({shop_data['x']}, {shop_data['y']}, {shop_data['z']})")
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Execute delete shop error: {str(e)}")
            go_back = lambda s: self._show_all_shops_panel(s) if from_all_shops else self._show_my_shops_panel(s)
            delete_title = f"{self.language_manager.GetText('SHOP_DELETE_SHOP_TITLE')}{self._get_shop_manage_title_suffix(shop_data)}"
            error_form = ActionForm(
                title=delete_title,
                content=self.language_manager.GetText("SHOP_DELETE_ERROR")
            )
            error_form.add_button(
                self.language_manager.GetText("SHOP_BACK_BUTTON"),
                on_click=go_back
            )
            player.send_form(error_form)

    # API 接口方法
    def api_get_shop_at_position(self, x: int, y: int, z: int, dimension: str) -> dict:
        """获取指定位置的商店信息（API接口）"""
        return self._get_shop_at_position(x, y, z, dimension)
    
    def api_get_player_shops(self, player_xuid: str) -> list:
        """获取玩家的所有商店（API接口）"""
        try:
            return self.db_manager.query_all(
                "SELECT * FROM button_shops WHERE owner_xuid = ? AND is_active = 1 ORDER BY create_time DESC",
                (player_xuid,)
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get player shops error: {str(e)}")
            return []
    
    def api_get_nearby_shops(self, x: int, z: int, dimension: str, radius: int = 1) -> list:
        """获取指定位置附近的商店（基于区块，用于浏览功能）"""
        try:
            chunk_x, chunk_z = self._get_chunk_coords(x, z)
            nearby_shops = []
            
            # 搜索指定半径内的区块
            for dx in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    search_chunk_x = chunk_x + dx
                    search_chunk_z = chunk_z + dz
                    
                    chunk_shops = self.db_manager.query_all(
                        "SELECT * FROM button_shops WHERE chunk_x = ? AND chunk_z = ? AND dimension = ? AND is_active = 1",
                        (search_chunk_x, search_chunk_z, dimension)
                    )
                    nearby_shops.extend(chunk_shops)
            
            return nearby_shops
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get nearby shops error: {str(e)}")
            return []
    
    def api_get_all_active_shops(self) -> list:
        """获取所有活跃的商店"""
        try:
            return self.db_manager.query_all(
                "SELECT * FROM button_shops WHERE is_active = 1 ORDER BY create_time DESC"
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Get all active shops error: {str(e)}")
            return []
    
    def api_purchase_from_shop(self, shop_id: int, buyer_xuid: str, quantity: int) -> tuple[bool, str]:
        """从商店购买商品（API接口）"""
        try:
            # 获取商店信息
            shop_data = self._get_shop_by_id(shop_id)
            if not shop_data:
                return False, self.language_manager.GetText("SHOP_API_NOT_FOUND")
            
            # 通过xuid查找买家
            buyer_player = None
            for player in self.server.online_players:
                if str(player.unique_id) == buyer_xuid:
                    buyer_player = player
                    break
            
            if not buyer_player:
                return False, self.language_manager.GetText("SHOP_API_BUYER_OFFLINE")
            
            # 执行购买
            return self._execute_purchase(buyer_player, shop_data, quantity)
            
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] API purchase error: {str(e)}")
            return False, self.language_manager.GetText("SHOP_API_PURCHASE_ERROR")
