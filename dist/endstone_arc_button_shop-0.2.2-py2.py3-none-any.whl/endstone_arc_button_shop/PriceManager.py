import os
import json
import random
import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple


MAIN_PATH = 'plugins/ARCButtonShop'


class PriceManager:
    """官方定价管理器 - 管理统一价格配置、动态定价和每日波动"""

    def __init__(self, plugin):
        self.plugin = plugin
        self.official_prices = {}  # item_type -> {'sell': int, 'buy': int}
        self.dynamic_pricing_config = {}
        self.daily_fluctuation_config = {}
        self.price_adjustments = {}  # item_type -> {'demand_sell_adjust': float, 'demand_buy_adjust': float, 'daily_adjust_percent': float, 'last_updated': str}
        self.config_path = Path(MAIN_PATH) / "official_prices.yml"
        self._last_daily_reset_date = None
        self._last_recovery_time = None
        self._load_config()

    def _safe_log(self, level: str, message: str):
        if hasattr(self.plugin, '_safe_log'):
            self.plugin._safe_log(level, message)
        else:
            print(f"[{level.upper()}] {message}")

    # ==================== 配置加载 ====================

    def _load_config(self):
        """加载官方定价配置文件"""
        self.config_path.parent.mkdir(exist_ok=True)

        if not self.config_path.exists():
            self._create_default_config()
            return

        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                content = f.read()
            self._parse_config(content)
            self._safe_log('info', f"[ARCButtonShop] Loaded official prices: {len(self.official_prices)} items")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to load official_prices.yml: {e}")
            self.official_prices = {}

    def _create_default_config(self):
        """创建默认配置文件"""
        default_content = """# 官方定价配置文件
# 物品类型: 出售价(sell)和回收价(buy)
# sell: 玩家从系统商店购买的价格
# buy: 玩家出售给系统商店的价格

prices:
  minecraft:diamond:
    sell: 1000
    buy: 900
  minecraft:iron_ingot:
    sell: 100
    buy: 80
  minecraft:gold_ingot:
    sell: 500
    buy: 400
  minecraft:coal:
    sell: 20
    buy: 15
  minecraft:emerald:
    sell: 800
    buy: 650
  minecraft:lapis_lazuli:
    sell: 150
    buy: 120
  minecraft:redstone:
    sell: 30
    buy: 20
  minecraft:netherite_ingot:
    sell: 5000
    buy: 4000
  minecraft:obsidian:
    sell: 50
    buy: 35
  minecraft:ender_pearl:
    sell: 200
    buy: 150

# 动态定价配置
dynamic_pricing:
  enabled: true
  # 需求驱动的价格调整
  demand_adjustment:
    # 统计时间窗口（分钟）
    time_window_minutes: 60
    # 交易量阈值 - 超过此数量开始调价
    sell_threshold: 10
    buy_threshold: 10
    # 每超一个阈值的价格调整比例
    sell_increase_rate: 0.02
    buy_decrease_rate: 0.02
    # 价格调整上限
    max_sell_increase: 0.50
    max_buy_decrease: 0.30
    # 价格恢复速率（每分钟向基准价回归的比例）
    recovery_rate_per_minute: 0.005
  # 每日随机波动
  daily_fluctuation:
    enabled: true
    # 每日随机波动的物品种类数
    item_count: 3
    # 波动范围百分比（最小和最大）
    min_percent: -15
    max_percent: 15
    # 波动重置时间（24小时制，0=午夜）
    reset_hour: 0
"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                f.write(default_content)
            self._parse_config(default_content)
            self._safe_log('info', "[ARCButtonShop] Created default official_prices.yml")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Failed to create default config: {e}")

    def _parse_config(self, content: str):
        """解析YAML配置（简化版，不依赖PyYAML）"""
        self.official_prices = {}
        self.dynamic_pricing_config = {}
        self.daily_fluctuation_config = {}

        lines = content.split('\n')
        current_section = None
        current_item = None
        indent_stack = []

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            # 计算缩进层级
            indent = len(line) - len(line.lstrip())

            if stripped.startswith('prices:'):
                current_section = 'prices'
                continue
            elif stripped.startswith('dynamic_pricing:'):
                current_section = 'dynamic_pricing'
                continue
            elif stripped.startswith('demand_adjustment:'):
                current_section = 'demand_adjustment'
                continue
            elif stripped.startswith('daily_fluctuation:'):
                current_section = 'daily_fluctuation'
                continue

            if current_section == 'prices':
                # 物品类型行 (minecraft:diamond:)
                if indent == 2 and stripped.endswith(':') and not ':' in stripped[:-1]:
                    current_item = stripped[:-1].strip()
                    if current_item not in self.official_prices:
                        self.official_prices[current_item] = {}
                # 物品类型行带冒号 (minecraft:diamond:  这种格式)
                elif indent == 2 and ':' in stripped:
                    parts = stripped.split(':', 1)
                    if parts[0].strip().startswith('minecraft:'):
                        current_item = parts[0].strip()
                        if current_item not in self.official_prices:
                            self.official_prices[current_item] = {}
                # sell/buy 价格行
                elif indent == 4 and current_item:
                    if stripped.startswith('sell:'):
                        try:
                            price = int(stripped.split(':', 1)[1].strip())
                            self.official_prices[current_item]['sell'] = price
                        except (ValueError, IndexError):
                            pass
                    elif stripped.startswith('buy:'):
                        try:
                            price = int(stripped.split(':', 1)[1].strip())
                            self.official_prices[current_item]['buy'] = price
                        except (ValueError, IndexError):
                            pass

            elif current_section == 'demand_adjustment':
                key_map = {
                    'time_window_minutes': 'time_window_minutes',
                    'sell_threshold': 'sell_threshold',
                    'buy_threshold': 'buy_threshold',
                    'sell_increase_rate': 'sell_increase_rate',
                    'buy_decrease_rate': 'buy_decrease_rate',
                    'max_sell_increase': 'max_sell_increase',
                    'max_buy_decrease': 'max_buy_decrease',
                    'recovery_rate_per_minute': 'recovery_rate_per_minute',
                }
                for key, mapped_key in key_map.items():
                    if stripped.startswith(f'{key}:'):
                        try:
                            value = stripped.split(':', 1)[1].strip()
                            self.dynamic_pricing_config[mapped_key] = float(value)
                        except (ValueError, IndexError):
                            pass
                        break

            elif current_section == 'daily_fluctuation':
                key_map = {
                    'enabled': 'enabled',
                    'item_count': 'item_count',
                    'min_percent': 'min_percent',
                    'max_percent': 'max_percent',
                    'reset_hour': 'reset_hour',
                }
                for key, mapped_key in key_map.items():
                    if stripped.startswith(f'{key}:'):
                        try:
                            value = stripped.split(':', 1)[1].strip()
                            if mapped_key == 'enabled':
                                self.daily_fluctuation_config[mapped_key] = value.lower() == 'true'
                            else:
                                self.daily_fluctuation_config[mapped_key] = float(value)
                        except (ValueError, IndexError):
                            pass
                        break

            elif current_section == 'dynamic_pricing':
                if stripped.startswith('enabled:'):
                    try:
                        value = stripped.split(':', 1)[1].strip()
                        self.dynamic_pricing_config['enabled'] = value.lower() == 'true'
                    except (ValueError, IndexError):
                        pass

        self._safe_log('info', f"[ARCButtonShop] Parsed {len(self.official_prices)} official prices, dynamic_pricing={self.dynamic_pricing_config.get('enabled', False)}")

    def reload_config(self):
        """重新加载配置文件"""
        self.official_prices = {}
        self.dynamic_pricing_config = {}
        self.daily_fluctuation_config = {}
        self._load_config()

    # ==================== 价格查询 ====================

    def has_official_price(self, item_type: str) -> bool:
        """检查物品是否有官方定价"""
        return item_type in self.official_prices

    def get_base_price(self, item_type: str, shop_type: str) -> Optional[int]:
        """获取物品基准价格"""
        if item_type not in self.official_prices:
            return None
        prices = self.official_prices[item_type]
        if shop_type == 'sell':
            return prices.get('sell')
        else:
            return prices.get('buy')

    def get_all_priced_items(self) -> Dict:
        """获取所有有官方定价的物品"""
        return dict(self.official_prices)

    def get_item_display_name(self, item_type: str) -> str:
        """获取物品显示名称（从类型名提取）"""
        # minecraft:diamond -> Diamond
        name = item_type.split(':')[-1] if ':' in item_type else item_type
        return name.replace('_', ' ').title()

    # ==================== 动态定价 ====================

    def get_price_adjustment(self, item_type: str) -> Dict:
        """获取物品的当前价格调整状态"""
        if item_type not in self.price_adjustments:
            return {
                'demand_sell_adjust': 0.0,
                'demand_buy_adjust': 0.0,
                'daily_adjust_percent': 0.0,
                'last_updated': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        return self.price_adjustments[item_type]

    def calculate_final_price(self, item_type: str, shop_type: str, discount_percent: float = 0.0) -> Optional[int]:
        """
        计算最终价格
        shop_type: 'sell'(玩家购买) 或 'buy'(玩家出售给商店)
        discount_percent: 商店级折扣百分比（负数=优惠，正数=加价）
        """
        base_price = self.get_base_price(item_type, shop_type)
        if base_price is None:
            return None

        adjustments = self.get_price_adjustment(item_type)

        if shop_type == 'sell':
            demand_adj = adjustments['demand_sell_adjust']
        else:
            demand_adj = adjustments['demand_buy_adjust']

        daily_adj = adjustments['daily_adjust_percent'] / 100.0

        # 最终价格 = 基准价 * (1 + 需求调整 + 日波动) * (1 + 折扣/100)
        multiplier = (1.0 + demand_adj + daily_adj) * (1.0 + discount_percent / 100.0)
        final_price = int(base_price * multiplier)

        # 确保价格不低于1
        return max(1, final_price)

    def record_trade_volume(self, item_type: str, shop_type: str, quantity: int, db_manager):
        """记录交易量用于动态定价"""
        if not self.dynamic_pricing_config.get('enabled', False):
            return

        try:
            trade_data = {
                'item_type': item_type,
                'trade_type': shop_type,  # 'sell'=玩家购买, 'buy'=玩家出售
                'quantity': quantity,
                'trade_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            db_manager.insert("item_trade_volume", trade_data)
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Record trade volume error: {e}")

    def update_demand_pricing(self, item_type: str, db_manager):
        """根据交易量更新需求驱动的价格调整"""
        if not self.dynamic_pricing_config.get('enabled', False):
            return

        try:
            time_window = self.dynamic_pricing_config.get('time_window_minutes', 60)
            sell_threshold = self.dynamic_pricing_config.get('sell_threshold', 10)
            buy_threshold = self.dynamic_pricing_config.get('buy_threshold', 10)
            sell_increase_rate = self.dynamic_pricing_config.get('sell_increase_rate', 0.02)
            buy_decrease_rate = self.dynamic_pricing_config.get('buy_decrease_rate', 0.02)
            max_sell_increase = self.dynamic_pricing_config.get('max_sell_increase', 0.50)
            max_buy_decrease = self.dynamic_pricing_config.get('max_buy_decrease', 0.30)

            cutoff_time = (datetime.datetime.now() - datetime.timedelta(minutes=time_window)).strftime("%Y-%m-%d %H:%M:%S")

            # 统计出售商店的交易量（玩家购买，导致出售价上涨）
            sell_trades = db_manager.query_all(
                "SELECT COALESCE(SUM(quantity), 0) as total FROM item_trade_volume WHERE item_type = ? AND trade_type = 'sell' AND trade_time >= ?",
                (item_type, cutoff_time)
            )
            sell_volume = sell_trades[0]['total'] if sell_trades else 0

            # 统计收购商店的交易量（玩家出售，导致回收价下跌）
            buy_trades = db_manager.query_all(
                "SELECT COALESCE(SUM(quantity), 0) as total FROM item_trade_volume WHERE item_type = ? AND trade_type = 'buy' AND trade_time >= ?",
                (item_type, cutoff_time)
            )
            buy_volume = buy_trades[0]['total'] if buy_trades else 0

            # 计算需求调整
            demand_sell_adjust = 0.0
            if sell_volume > sell_threshold:
                demand_sell_adjust = min(
                    (sell_volume / sell_threshold - 1) * sell_increase_rate,
                    max_sell_increase
                )

            demand_buy_adjust = 0.0
            if buy_volume > buy_threshold:
                demand_buy_adjust = max(
                    -((buy_volume / buy_threshold - 1) * buy_decrease_rate),
                    -max_buy_decrease
                )

            # 更新调整数据
            current = self.get_price_adjustment(item_type)
            current['demand_sell_adjust'] = demand_sell_adjust
            current['demand_buy_adjust'] = demand_buy_adjust
            current['last_updated'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.price_adjustments[item_type] = current

            # 持久化到数据库
            self._save_price_adjustment(item_type, db_manager)

        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Update demand pricing error: {e}")

    def _save_price_adjustment(self, item_type: str, db_manager):
        """保存价格调整到数据库"""
        try:
            adj = self.price_adjustments.get(item_type)
            if not adj:
                return

            existing = db_manager.query_one(
                "SELECT id FROM price_adjustments WHERE item_type = ?",
                (item_type,)
            )

            if existing:
                db_manager.update(
                    table='price_adjustments',
                    data={
                        'demand_sell_adjust': adj['demand_sell_adjust'],
                        'demand_buy_adjust': adj['demand_buy_adjust'],
                        'daily_adjust_percent': adj['daily_adjust_percent'],
                        'last_updated': adj['last_updated']
                    },
                    where='item_type = ?',
                    params=(item_type,)
                )
            else:
                db_manager.insert('price_adjustments', {
                    'item_type': item_type,
                    'demand_sell_adjust': adj['demand_sell_adjust'],
                    'demand_buy_adjust': adj['demand_buy_adjust'],
                    'daily_adjust_percent': adj['daily_adjust_percent'],
                    'last_updated': adj['last_updated']
                })
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Save price adjustment error: {e}")

    def load_price_adjustments_from_db(self, db_manager):
        """从数据库加载价格调整状态"""
        try:
            rows = db_manager.query_all("SELECT * FROM price_adjustments")
            if rows:
                for row in rows:
                    self.price_adjustments[row['item_type']] = {
                        'demand_sell_adjust': float(row.get('demand_sell_adjust', 0)),
                        'demand_buy_adjust': float(row.get('demand_buy_adjust', 0)),
                        'daily_adjust_percent': float(row.get('daily_adjust_percent', 0)),
                        'last_updated': row.get('last_updated', datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    }
                self._safe_log('info', f"[ARCButtonShop] Loaded {len(rows)} price adjustments from DB")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Load price adjustments from DB error: {e}")

    # ==================== 每日波动 ====================

    def check_and_apply_daily_fluctuation(self, db_manager):
        """检查并应用每日随机波动"""
        if not self.daily_fluctuation_config.get('enabled', False):
            return

        now = datetime.datetime.now()
        today = now.date()

        # 检查是否需要重置
        if self._last_daily_reset_date is None or self._last_daily_reset_date != today:
            reset_hour = int(self.daily_fluctuation_config.get('reset_hour', 0))
            if now.hour >= reset_hour:
                self._apply_daily_fluctuation(db_manager)
                self._last_daily_reset_date = today

    def _apply_daily_fluctuation(self, db_manager):
        """应用每日随机波动"""
        item_count = int(self.daily_fluctuation_config.get('item_count', 3))
        min_percent = self.daily_fluctuation_config.get('min_percent', -15)
        max_percent = self.daily_fluctuation_config.get('max_percent', 15)

        priced_items = list(self.official_prices.keys())
        if not priced_items:
            return

        # 随机选择物品
        selected_items = random.sample(priced_items, min(item_count, len(priced_items)))

        # 先重置所有物品的日波动
        for item_type in self.official_prices:
            if item_type not in self.price_adjustments:
                self.price_adjustments[item_type] = {
                    'demand_sell_adjust': 0.0,
                    'demand_buy_adjust': 0.0,
                    'daily_adjust_percent': 0.0,
                    'last_updated': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            else:
                self.price_adjustments[item_type]['daily_adjust_percent'] = 0.0

        # 为选中的物品设置随机波动
        for item_type in selected_items:
            fluctuation = random.uniform(min_percent, max_percent)
            fluctuation = round(fluctuation, 1)

            if item_type not in self.price_adjustments:
                self.price_adjustments[item_type] = {
                    'demand_sell_adjust': 0.0,
                    'demand_buy_adjust': 0.0,
                    'daily_adjust_percent': fluctuation,
                    'last_updated': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            else:
                self.price_adjustments[item_type]['daily_adjust_percent'] = fluctuation

            self._save_price_adjustment(item_type, db_manager)

            sign = "+" if fluctuation > 0 else ""
            self._safe_log('info', f"[ARCButtonShop] Daily fluctuation: {item_type} {sign}{fluctuation}%")

        self._safe_log('info', f"[ARCButtonShop] Applied daily fluctuation to {len(selected_items)} items")

    # ==================== 价格恢复 ====================

    def apply_price_recovery(self, db_manager):
        """每分钟调用，价格向基准价回归"""
        if not self.dynamic_pricing_config.get('enabled', False):
            return

        recovery_rate = self.dynamic_pricing_config.get('recovery_rate_per_minute', 0.005)
        if recovery_rate <= 0:
            return

        changed = False
        for item_type, adj in self.price_adjustments.items():
            # 需求调整向0回归
            if adj['demand_sell_adjust'] != 0:
                if adj['demand_sell_adjust'] > 0:
                    adj['demand_sell_adjust'] = max(0, adj['demand_sell_adjust'] - recovery_rate)
                else:
                    adj['demand_sell_adjust'] = min(0, adj['demand_sell_adjust'] + recovery_rate)
                changed = True

            if adj['demand_buy_adjust'] != 0:
                if adj['demand_buy_adjust'] > 0:
                    adj['demand_buy_adjust'] = max(0, adj['demand_buy_adjust'] - recovery_rate)
                else:
                    adj['demand_buy_adjust'] = min(0, adj['demand_buy_adjust'] + recovery_rate)
                changed = True

        if changed:
            for item_type in self.price_adjustments:
                self._save_price_adjustment(item_type, db_manager)

    # ==================== 清理过期数据 ====================

    def cleanup_old_trade_volumes(self, db_manager, days: int = 7):
        """清理过期的交易量数据"""
        try:
            cutoff_time = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
            db_manager.execute(
                "DELETE FROM item_trade_volume WHERE trade_time < ?",
                (cutoff_time,)
            )
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Cleanup old trade volumes error: {e}")

    # ==================== 管理接口 ====================

    def reset_all_adjustments(self, db_manager):
        """重置所有动态价格调整"""
        self.price_adjustments = {}
        try:
            db_manager.execute("DELETE FROM price_adjustments")
            self._safe_log('info', "[ARCButtonShop] All price adjustments reset")
        except Exception as e:
            self._safe_log('error', f"[ARCButtonShop] Reset price adjustments error: {e}")

    def get_price_info_string(self, item_type: str, discount_percent: float = 0.0) -> str:
        """获取物品价格信息字符串（用于UI显示）"""
        if item_type not in self.official_prices:
            return ""

        prices = self.official_prices[item_type]
        adj = self.get_price_adjustment(item_type)

        info_parts = []
        info_parts.append(f"Base Sell: {prices.get('sell', 'N/A')}")
        info_parts.append(f"Base Buy: {prices.get('buy', 'N/A')}")

        if adj['demand_sell_adjust'] != 0:
            info_parts.append(f"Demand Sell Adj: {adj['demand_sell_adjust']:+.1%}")
        if adj['demand_buy_adjust'] != 0:
            info_parts.append(f"Demand Buy Adj: {adj['demand_buy_adjust']:+.1%}")
        if adj['daily_adjust_percent'] != 0:
            info_parts.append(f"Daily Fluctuation: {adj['daily_adjust_percent']:+.1f}%")
        if discount_percent != 0:
            info_parts.append(f"Shop Discount: {discount_percent:+.1f}%")

        final_sell = self.calculate_final_price(item_type, 'sell', discount_percent)
        final_buy = self.calculate_final_price(item_type, 'buy', discount_percent)
        if final_sell:
            info_parts.append(f"Final Sell: {final_sell}")
        if final_buy:
            info_parts.append(f"Final Buy: {final_buy}")

        return "\n".join(info_parts)

    def get_daily_fluctuation_summary(self) -> str:
        """获取今日波动摘要"""
        items = []
        for item_type, adj in self.price_adjustments.items():
            if adj['daily_adjust_percent'] != 0:
                name = self.get_item_display_name(item_type)
                sign = "+" if adj['daily_adjust_percent'] > 0 else ""
                items.append(f"{name}: {sign}{adj['daily_adjust_percent']:.1f}%")

        if not items:
            return "No daily fluctuations today"
        return "\n".join(items)